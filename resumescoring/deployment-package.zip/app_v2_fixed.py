import os
import json
import boto3
import math
import re
from typing import List, Dict, Optional, Tuple
from pydantic import BaseModel, Field
from fastapi import FastAPI, HTTPException
from mangum import Mangum

app = FastAPI()

# -------- Environment Configuration --------
REGION = os.getenv("AWS_REGION", "us-east-2")
VECTOR_BUCKET = os.getenv("VECTOR_BUCKET")
VECTOR_INDEX = os.getenv("VECTOR_INDEX")
BEDROCK_EMBED_MODEL = os.getenv("BEDROCK_EMBED_MODEL", "amazon.titan-embed-text-v2:0")
BEDROCK_LLM_MODEL = os.getenv("BEDROCK_LLM_MODEL", "us.anthropic.claude-3-5-sonnet-20241022-v2:0")

print(f"[INIT] REGION={REGION}, VECTOR_BUCKET={VECTOR_BUCKET}, VECTOR_INDEX={VECTOR_INDEX}")
print(f"[INIT] EMBED_MODEL={BEDROCK_EMBED_MODEL}, LLM_MODEL={BEDROCK_LLM_MODEL}")

# Initialize AWS clients
bedrock = boto3.client("bedrock-runtime", region_name=REGION)

try:
    s3vector = boto3.client("s3vectors", region_name=REGION)
    print("[INIT] ✅ S3 Vector client initialized successfully.")
except Exception as e:
    print(f"[INIT] ⚠️ WARNING: Could not initialize s3vectors client: {e}")
    s3vector = None


# -------- Request Models --------
class ResumeMatchRequest(BaseModel):
    resume_name: str = Field(..., description="Name/ID of the resume to match")
    job_description: str = Field(..., description="Job description text to match against")
    use_detailed_analysis: Optional[bool] = Field(default=False, description="Use Claude for detailed analysis")


# -------- Helper Functions --------

def invoke_claude(prompt: str, max_tokens: int = 3000) -> str:
    """
    Invoke Claude and return the response text.

    Args:
        prompt: Prompt to send to Claude
        max_tokens: Maximum tokens in response

    Returns:
        Response text from Claude
    """
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": max_tokens,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.1
    }

    response = bedrock.invoke_model(
        modelId=BEDROCK_LLM_MODEL,
        body=json.dumps(body)
    )

    result = json.loads(response['body'].read())
    content = result['content'][0]['text']

    # Clean JSON from markdown if present
    content = content.strip()
    if '```json' in content:
        content = content.split('```json')[1].split('```')[0]
    elif '```' in content:
        content = content.split('```')[1].split('```')[0]

    return content.strip()


def get_embedding(text: str) -> List[float]:
    """Generate embedding using Amazon Titan."""
    print(f"[BEDROCK] Generating embedding for text: {text[:60]}...")

    body = {"inputText": text[:8000]}  # Titan limit
    response = bedrock.invoke_model(
        modelId=BEDROCK_EMBED_MODEL,
        body=json.dumps(body),
        accept="application/json",
        contentType="application/json"
    )

    result = json.loads(response["body"].read())
    print("[BEDROCK] Embedding generated successfully.")
    return result["embedding"]


def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """Calculate cosine similarity between two vectors."""
    if not vec1 or not vec2:
        return 0.0

    if len(vec1) != len(vec2):
        print(f"[WARNING] Vector length mismatch: {len(vec1)} vs {len(vec2)}")
        return 0.0

    dot_product = sum(a * b for a, b in zip(vec1, vec2))
    magnitude1 = math.sqrt(sum(a * a for a in vec1))
    magnitude2 = math.sqrt(sum(b * b for b in vec2))

    if magnitude1 == 0 or magnitude2 == 0:
        return 0.0

    similarity = dot_product / (magnitude1 * magnitude2)
    return float(max(0.0, min(1.0, similarity)))


def extract_jd_requirements_comprehensive(jd_text: str) -> Dict:
    """
    Extract comprehensive requirements from JD using Claude.
    NO REGEX - Let Claude understand the context!

    Args:
        jd_text: Job description text

    Returns:
        Comprehensive requirements dictionary
    """
    print(f"[CLAUDE_JD] 🧠 Extracting comprehensive JD requirements...")

    # Truncate if too long
    max_chars = 15000
    if len(jd_text) > max_chars:
        print(f"[CLAUDE_JD] ⚠️ Truncating JD from {len(jd_text)} to {max_chars} chars")
        jd_text = jd_text[:max_chars]

    prompt = f"""Analyze this job description comprehensively and extract ALL requirements.

Job Description:
{jd_text}

Extract and return ONLY valid JSON (no markdown, no explanations):

{{
    "job_title": "Senior Full Stack Developer",
    "core_skills": [
        {{"name": "Python", "importance": "critical", "min_years": 5, "variants": ["Python", "python3", "py"]}},
        {{"name": "AWS", "importance": "critical", "min_years": 3, "variants": ["AWS", "Amazon Web Services"]}}
    ],
    "secondary_skills": [
        {{"name": "Docker", "importance": "required", "min_years": 2, "variants": ["Docker", "containers"]}}
    ],
    "nice_to_have_skills": [
        {{"name": "Kubernetes", "importance": "preferred", "variants": ["Kubernetes", "K8s", "k8s"]}}
    ],
    "keywords_to_search": ["microservices", "CI/CD", "agile", "production", "scale"],
    "experience_requirements": {{
        "total_years": 5,
        "seniority": "senior",
        "domain": ["fintech", "banking", "enterprise"]
    }},
    "education": "Bachelor's in Computer Science or equivalent",
    "certifications": ["AWS Certified Solutions Architect"],
    "must_have_achievements": ["led team", "production systems", "scaled applications"]
}}

Include all skill variants to improve matching (e.g., .NET = dotnet, C# = csharp).
Return ONLY valid JSON."""

    try:
        content = invoke_claude(prompt, max_tokens=3000)
        jd_requirements = json.loads(content)

        print(f"[CLAUDE_JD] ✅ Successfully extracted JD requirements!")
        print(f"[CLAUDE_JD]   Core skills: {len(jd_requirements.get('core_skills', []))}")
        print(f"[CLAUDE_JD]   Secondary skills: {len(jd_requirements.get('secondary_skills', []))}")
        print(f"[CLAUDE_JD]   Nice-to-have: {len(jd_requirements.get('nice_to_have_skills', []))}")

        return jd_requirements

    except Exception as e:
        print(f"[CLAUDE_JD] ❌ Error: {e}")
        import traceback
        traceback.print_exc()

        # Return minimal fallback
        return {
            "job_title": "Unknown",
            "core_skills": [],
            "secondary_skills": [],
            "nice_to_have_skills": [],
            "keywords_to_search": [],
            "experience_requirements": {"total_years": 0},
            "error": str(e)
        }


def search_resume_chunks_for_skill(content_chunks: List[Dict], skill_obj: Dict) -> Optional[Dict]:
    """
    Search resume content chunks for a specific skill using embeddings.
    This is the RIGHT way - semantic search, not regex!

    Args:
        content_chunks: List of resume content chunks with embeddings
        skill_obj: Skill object with name, variants, min_years

    Returns:
        Best matching chunk with similarity score, or None
    """
    skill_name = skill_obj['name']
    variants = skill_obj.get('variants', [skill_name])

    print(f"[CHUNK_SEARCH] Searching for skill: {skill_name} (variants: {variants})")

    # Create search query embedding - ask about professional experience
    query = f"Professional experience with {skill_name} in software development"
    query_embedding = get_embedding(query)

    # Search through chunks
    best_match = None
    best_similarity = 0.0

    for chunk in content_chunks:
        chunk_embedding = chunk.get('embedding', [])
        if not chunk_embedding:
            continue

        similarity = cosine_similarity(query_embedding, chunk_embedding)

        if similarity > best_similarity:
            best_similarity = similarity
            best_match = chunk

    # Threshold for considering it a match
    if best_similarity > 0.60:  # Lower threshold - semantic matching is fuzzy
        print(f"[CHUNK_SEARCH] ✅ Found {skill_name}: similarity={best_similarity:.4f}")
        return {
            'chunk': best_match,
            'similarity': best_similarity,
            'text': best_match.get('text', '')[:500]
        }
    else:
        print(f"[CHUNK_SEARCH] ❌ Not found: {skill_name} (best: {best_similarity:.4f})")
        return None


def extract_skill_context_with_claude(chunk_text: str, skill_obj: Dict) -> Dict:
    """
    Use Claude to extract detailed context about a skill from resume chunk.

    Args:
        chunk_text: Resume text chunk
        skill_obj: Skill object with name and requirements

    Returns:
        Detailed skill context
    """
    skill_name = skill_obj['name']
    min_years = skill_obj.get('min_years', 0)

    prompt = f"""Analyze this resume section for experience with {skill_name}:

Resume Section:
{chunk_text}

Determine if the candidate has {skill_name} experience and extract details.
Return ONLY valid JSON:

{{
    "has_skill": true/false,
    "years_mentioned": 5,
    "proficiency_level": "expert/advanced/intermediate/basic",
    "context": "brief description of how skill was used",
    "meets_requirement": true/false,
    "relevant_quote": "exact quote from resume showing this skill",
    "confidence": 0.95
}}

Requirements: {min_years}+ years of {skill_name} experience
Return ONLY valid JSON."""

    try:
        content = invoke_claude(prompt, max_tokens=1000)
        skill_context = json.loads(content)
        return skill_context

    except Exception as e:
        print(f"[SKILL_CONTEXT] ❌ Error extracting context for {skill_name}: {e}")
        return {
            "has_skill": False,
            "years_mentioned": 0,
            "proficiency_level": "unknown",
            "context": "",
            "meets_requirement": False,
            "error": str(e)
        }


def search_resume_comprehensively(resume_data: Dict, jd_requirements: Dict) -> Dict:
    """
    Search resume using BOTH metadata AND content chunks.
    This is what we should have been doing all along!

    Args:
        resume_data: Resume data with skills_vector and content_chunks
        jd_requirements: Extracted JD requirements

    Returns:
        Comprehensive search results
    """
    print("[COMPREHENSIVE_SEARCH] 🔍 Searching resume comprehensively...")

    metadata = resume_data['skills_vector']['metadata']
    content_chunks = resume_data['content_chunks']

    results = {
        "core_skills_found": [],
        "secondary_skills_found": [],
        "nice_to_have_found": [],
        "keywords_found": [],
        "experience_analysis": {}
    }

    # Helper function to check metadata first
    def check_metadata_for_skill(skill_name: str, variants: List[str]) -> bool:
        """Check if skill exists in metadata (fast check)."""
        all_metadata_skills = ','.join([
            metadata.get('tech_skills', ''),
            metadata.get('cloud_skills', ''),
            metadata.get('devops_tools', ''),
            metadata.get('databases', '')
        ]).lower()

        # Check all variants
        for variant in [skill_name.lower()] + [v.lower() for v in variants]:
            if variant in all_metadata_skills:
                return True
        return False

    # Search for core skills
    print(f"[COMPREHENSIVE_SEARCH] Searching {len(jd_requirements.get('core_skills', []))} core skills...")
    for skill_obj in jd_requirements.get('core_skills', []):
        skill_name = skill_obj['name']
        variants = skill_obj.get('variants', [skill_name])

        # First, quick check in metadata
        in_metadata = check_metadata_for_skill(skill_name, variants)

        # Then, deep search in content chunks using embeddings
        chunk_result = search_resume_chunks_for_skill(content_chunks, skill_obj)

        if in_metadata or chunk_result:
            # Extract detailed context if found in chunks
            if chunk_result:
                context = extract_skill_context_with_claude(
                    chunk_result['text'],
                    skill_obj
                )
            else:
                # Found in metadata but not in chunks - assume basic proficiency
                context = {
                    "has_skill": True,
                    "years_mentioned": 0,
                    "proficiency_level": "mentioned",
                    "context": f"Skill listed in resume: {skill_name}",
                    "meets_requirement": False
                }

            results['core_skills_found'].append({
                'skill': skill_name,
                'found_in_metadata': in_metadata,
                'found_in_content': chunk_result is not None,
                'similarity': chunk_result['similarity'] if chunk_result else 0.0,
                'context': context,
                'chunk_text': chunk_result['text'] if chunk_result else ""
            })

            print(f"[COMPREHENSIVE_SEARCH] ✅ Found core skill: {skill_name}")
        else:
            print(f"[COMPREHENSIVE_SEARCH] ❌ Missing core skill: {skill_name}")

    # Search for secondary skills (same process)
    print(f"[COMPREHENSIVE_SEARCH] Searching {len(jd_requirements.get('secondary_skills', []))} secondary skills...")
    for skill_obj in jd_requirements.get('secondary_skills', []):
        skill_name = skill_obj['name']
        variants = skill_obj.get('variants', [skill_name])

        in_metadata = check_metadata_for_skill(skill_name, variants)
        chunk_result = search_resume_chunks_for_skill(content_chunks, skill_obj)

        if in_metadata or chunk_result:
            if chunk_result:
                context = extract_skill_context_with_claude(chunk_result['text'], skill_obj)
            else:
                context = {
                    "has_skill": True,
                    "years_mentioned": 0,
                    "proficiency_level": "mentioned",
                    "context": f"Skill listed in resume: {skill_name}"
                }

            results['secondary_skills_found'].append({
                'skill': skill_name,
                'found_in_metadata': in_metadata,
                'found_in_content': chunk_result is not None,
                'similarity': chunk_result['similarity'] if chunk_result else 0.0,
                'context': context
            })

    # Search for nice-to-have skills
    print(
        f"[COMPREHENSIVE_SEARCH] Searching {len(jd_requirements.get('nice_to_have_skills', []))} nice-to-have skills...")
    for skill_obj in jd_requirements.get('nice_to_have_skills', []):
        skill_name = skill_obj['name']
        variants = skill_obj.get('variants', [skill_name])

        in_metadata = check_metadata_for_skill(skill_name, variants)
        chunk_result = search_resume_chunks_for_skill(content_chunks, skill_obj)

        if in_metadata or chunk_result:
            results['nice_to_have_found'].append({
                'skill': skill_name,
                'found_in_metadata': in_metadata,
                'found_in_content': chunk_result is not None
            })

    # Search for keywords in chunks
    print(f"[COMPREHENSIVE_SEARCH] Searching for keywords...")
    for keyword in jd_requirements.get('keywords_to_search', []):
        # Simple check - is keyword mentioned in any chunk?
        for chunk in content_chunks[:10]:  # Check top 10 chunks
            if keyword.lower() in chunk.get('text', '').lower():
                results['keywords_found'].append(keyword)
                break

    # Analyze total experience
    years_exp = metadata.get('years_exp', '0')
    try:
        years_int = int(re.search(r'\d+', str(years_exp)).group()) if years_exp else 0
    except:
        years_int = 0

    required_years = jd_requirements.get('experience_requirements', {}).get('total_years', 0)

    results['experience_analysis'] = {
        'resume_years': years_int,
        'required_years': required_years,
        'meets_requirement': years_int >= required_years,
        'gap': max(0, required_years - years_int)
    }

    print(f"[COMPREHENSIVE_SEARCH] ✅ Search complete!")
    print(f"[COMPREHENSIVE_SEARCH]   Core skills found: {len(results['core_skills_found'])}")
    print(f"[COMPREHENSIVE_SEARCH]   Secondary skills found: {len(results['secondary_skills_found'])}")
    print(f"[COMPREHENSIVE_SEARCH]   Keywords found: {len(results['keywords_found'])}")

    return results


def calculate_advanced_score_v4(
        resume_data: Dict,
        jd_requirements: Dict,
        search_results: Dict
) -> Dict:
    """
    Calculate score based on comprehensive search results.
    Uses embeddings + Claude analysis - NO REGEX!

    Args:
        resume_data: Resume data
        jd_requirements: Extracted JD requirements
        search_results: Comprehensive search results

    Returns:
        Detailed scoring breakdown
    """
    print("[SCORING_V4] 📊 Calculating comprehensive score...")

    # 1. Core skills score (50% weight)
    core_total = len(jd_requirements.get('core_skills', []))
    core_found = len(search_results['core_skills_found'])

    if core_total > 0:
        core_base_score = core_found / core_total

        # Adjust for years/proficiency
        core_adjusted = core_base_score
        for skill_result in search_results['core_skills_found']:
            context = skill_result.get('context', {})
            if not context.get('meets_requirement', False):
                # Penalize if doesn't meet years requirement
                core_adjusted -= 0.05  # -5% per skill that doesn't meet years

        core_score = max(0.0, core_adjusted)
    else:
        core_score = 1.0

    # 2. Secondary skills score (20% weight)
    secondary_total = len(jd_requirements.get('secondary_skills', []))
    secondary_found = len(search_results['secondary_skills_found'])
    secondary_score = secondary_found / secondary_total if secondary_total > 0 else 1.0

    # 3. Nice-to-have score (10% weight)
    nice_total = len(jd_requirements.get('nice_to_have_skills', []))
    nice_found = len(search_results['nice_to_have_found'])
    nice_score = nice_found / nice_total if nice_total > 0 else 0.0

    # 4. Keyword score (10% weight)
    keyword_total = len(jd_requirements.get('keywords_to_search', []))
    keyword_found = len(search_results['keywords_found'])
    keyword_score = keyword_found / keyword_total if keyword_total > 0 else 0.0

    # 5. Experience score (10% weight)
    exp_analysis = search_results['experience_analysis']
    if exp_analysis['meets_requirement']:
        exp_score = 1.0
    else:
        gap = exp_analysis['gap']
        exp_score = max(0.0, 1.0 - (gap * 0.10))  # -10% per year short

    # Calculate weighted final score
    final_score = (
            0.50 * core_score +
            0.20 * secondary_score +
            0.10 * nice_score +
            0.10 * keyword_score +
            0.10 * exp_score
    )

    final_score_pct = int(final_score * 100)

    print(f"[SCORING_V4] ✅ FINAL SCORE: {final_score_pct}/100")
    print(f"[SCORING_V4]   Core skills: {core_score:.4f} ({core_found}/{core_total})")
    print(f"[SCORING_V4]   Secondary: {secondary_score:.4f} ({secondary_found}/{secondary_total})")
    print(f"[SCORING_V4]   Nice-to-have: {nice_score:.4f} ({nice_found}/{nice_total})")
    print(f"[SCORING_V4]   Keywords: {keyword_score:.4f} ({keyword_found}/{keyword_total})")
    print(f"[SCORING_V4]   Experience: {exp_score:.4f}")

    # Find missing critical skills
    missing_core = []
    for skill_obj in jd_requirements.get('core_skills', []):
        found = any(s['skill'] == skill_obj['name'] for s in search_results['core_skills_found'])
        if not found:
            missing_core.append(skill_obj['name'])

    return {
        "overall_score": final_score_pct,
        "final_score_decimal": round(final_score, 4),

        "breakdown": {
            "core_skills_score": round(core_score, 4),
            "secondary_skills_score": round(secondary_score, 4),
            "nice_to_have_score": round(nice_score, 4),
            "keyword_score": round(keyword_score, 4),
            "experience_score": round(exp_score, 4)
        },

        "core_skills_found": core_found,
        "core_skills_total": core_total,
        "core_skills_details": search_results['core_skills_found'],

        "secondary_skills_found": secondary_found,
        "secondary_skills_total": secondary_total,

        "missing_critical_skills": missing_core,

        "experience_analysis": exp_analysis,

        "keywords_matched": search_results['keywords_found'],

        "scoring_weights": {
            "core_skills": "50%",
            "secondary_skills": "20%",
            "nice_to_have": "10%",
            "keywords": "10%",
            "experience": "10%"
        }
    }


def search_resume_by_name(resume_name: str) -> Optional[Dict]:
    """Search for a specific resume in S3 Vector index by name."""
    print(f"[S3VECTOR] Searching for resume: {resume_name}")

    if not s3vector:
        raise Exception("S3 Vector client not initialized")

    try:
        search_query = f"Resume for candidate {resume_name}"
        search_embedding = get_embedding(search_query)

        resp = s3vector.query_vectors(
            vectorBucketName=VECTOR_BUCKET,
            indexName=VECTOR_INDEX,
            queryVector={"float32": search_embedding},
            topK=100,
            returnMetadata=True
        )

        results = resp.get("matches", resp.get("results", resp.get("vectors", [])))
        print(f"[S3VECTOR] Query returned {len(results)} results")

        resume_name_lower = resume_name.lower()
        resume_name_clean = resume_name.replace('.pdf', '').replace('.docx', '').replace('/', '_')

        skills_vector = None
        content_chunks = []

        for result in results:
            vector_key = result.get('key', '')
            metadata = result.get('metadata', {})
            embedding = result.get('vector', result.get('data', {}))
            if isinstance(embedding, dict):
                embedding = embedding.get('float32', [])

            file_name = metadata.get('file_name', '')

            if (resume_name_lower in vector_key.lower() or
                    resume_name_lower in file_name.lower() or
                    resume_name_clean.lower() in vector_key.lower()):

                if '_SKILLS' in vector_key:
                    skills_vector = {
                        'vector_id': vector_key,
                        'metadata': metadata,
                        'embedding': embedding
                    }
                elif metadata.get('type') == 'content':
                    content_chunks.append({
                        'vector_id': vector_key,
                        'metadata': metadata,
                        'embedding': embedding,
                        'text': metadata.get('chunk_text', '')
                    })

        if not skills_vector:
            return None

        print(f"[S3VECTOR] ✅ Found resume: {skills_vector['metadata'].get('name', 'Unknown')}")
        print(f"[S3VECTOR] ✅ Found {len(content_chunks)} content chunks")

        return {
            'skills_vector': skills_vector,
            'content_chunks': content_chunks
        }

    except Exception as e:
        print(f"[S3VECTOR] ❌ Error: {e}")
        import traceback
        traceback.print_exc()
        raise


# -------- API Endpoints --------

@app.post("/match-resume")
async def match_resume(request: ResumeMatchRequest):
    """Match resume using comprehensive embedding search + Claude analysis."""
    print(f"\n{'=' * 80}")
    print(f"[API] Processing Resume Match Request (V4 - Production Ready)")
    print(f"      Resume: {request.resume_name}")
    print(f"      JD Length: {len(request.job_description)} chars")
    print(f"{'=' * 80}\n")

    try:
        # Step 1: Search for resume
        print("[STEP 1] Searching for resume in S3 Vector...")
        resume_data = search_resume_by_name(request.resume_name)

        if not resume_data:
            raise HTTPException(
                status_code=404,
                detail=f"Resume not found: {request.resume_name}"
            )

        metadata = resume_data['skills_vector']['metadata']

        # Step 2: Extract JD requirements using Claude (NO REGEX!)
        print("[STEP 2] Extracting JD requirements using Claude...")
        jd_requirements = extract_jd_requirements_comprehensive(request.job_description)

        # Step 3: Search resume comprehensively (metadata + content chunks)
        print("[STEP 3] Searching resume comprehensively...")
        search_results = search_resume_comprehensively(resume_data, jd_requirements)

        # Step 4: Calculate score
        print("[STEP 4] Calculating comprehensive score...")
        scoring_result = calculate_advanced_score_v4(resume_data, jd_requirements, search_results)

        # Prepare response
        result = {
            "status": "success",
            "resume_info": {
                "name": metadata.get("name", "Unknown"),
                "title": metadata.get("title", ""),
                "years_experience": metadata.get("years_exp", ""),
                "email": metadata.get("email", ""),
                "phone": metadata.get("phone", ""),
                "file_name": metadata.get("file_name", "")
            },
            "match_scores": scoring_result,
            "jd_requirements": jd_requirements
        }

        print(f"\n{'=' * 80}")
        print(f"[SUCCESS] Match Complete (V4)")
        print(f"          Overall Score: {scoring_result['overall_score']}/100")
        print(f"{'=' * 80}\n")

        return result

    except HTTPException:
        raise
    except Exception as e:
        print(f"[ERROR] {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "resume-matcher-v4-production",
        "version": "4.0.0",
        "features": [
            "Embedding-based semantic search",
            "Claude-powered JD analysis (NO REGEX)",
            "Comprehensive resume content search",
            "Metadata + content validation",
            "Detailed skill context extraction"
        ]
    }


# -------- Lambda Handler --------
asgi_handler = Mangum(app)


def lambda_handler(event, context):
    """Hybrid Lambda handler."""
    print("\n" + "=" * 80)
    print("[LAMBDA] V4 Handler Invoked")
    print("=" * 80)

    try:
        if "messageVersion" in event and "function" in event:
            params = event.get("parameters", [])
            resume_name = next((p["value"] for p in params if p["name"] == "resume_name"), None)
            job_description = next((p["value"] for p in params if p["name"] == "job_description"), None)

            if not resume_name or not job_description:
                raise ValueError("Missing required parameters")

            request = ResumeMatchRequest(
                resume_name=resume_name,
                job_description=job_description,
                use_detailed_analysis=False
            )

            import asyncio
            loop = asyncio.get_event_loop()
            result = loop.run_until_complete(match_resume(request))

            return {
                "messageVersion": "1.0",
                "response": {
                    "actionGroup": event.get("actionGroup"),
                    "function": event.get("function"),
                    "functionResponse": {
                        "responseBody": {
                            "TEXT": {
                                "body": json.dumps(result, indent=2)
                            }
                        }
                    }
                }
            }

        return asgi_handler(event, context)

    except Exception as e:
        print(f"[ERROR] {str(e)}")
        import traceback
        traceback.print_exc()

        error_response = {"error": str(e), "traceback": traceback.format_exc()}

        if "messageVersion" in event:
            return {
                "messageVersion": "1.0",
                "response": {
                    "actionGroup": event.get("actionGroup", ""),
                    "function": event.get("function", ""),
                    "functionResponse": {
                        "responseBody": {
                            "TEXT": {"body": json.dumps(error_response)}
                        }
                    }
                }
            }
        else:
            return {"statusCode": 500, "body": json.dumps(error_response)}


handler = lambda_handler