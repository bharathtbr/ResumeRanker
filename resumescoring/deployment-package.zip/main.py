import json
import os
import boto3

# Initialize AWS clients
s3 = boto3.client("s3")
textract = boto3.client("textract")
bedrock = boto3.client("bedrock-runtime")
s3vectors = boto3.client("s3vectors")

# Environment variables
VECTOR_BUCKET = os.environ["VECTOR_BUCKET"]
VECTOR_INDEX = os.environ["VECTOR_INDEX"]

print(f"[INIT] Loaded config: VECTOR_BUCKET={VECTOR_BUCKET}, VECTOR_INDEX={VECTOR_INDEX}")

def extract_text(bucket, key):
    """Extract text from .txt or PDF/DOCX using Textract"""
    print(f"[EXTRACT] Extracting text from s3://{bucket}/{key}")
    if key.lower().endswith(".txt"):
        tmp = f"/tmp/{os.path.basename(key)}"
        s3.download_file(bucket, key, tmp)
        with open(tmp, "r", encoding="utf-8") as f:
            return f.read()
    else:
        resp = textract.detect_document_text(
            Document={"S3Object": {"Bucket": bucket, "Name": key}}
        )
        text = " ".join(
            b["Text"] for b in resp["Blocks"] if b["BlockType"] == "LINE"
        )
        return text

def get_embedding(text):
    """Generate embeddings using Bedrock Titan model"""
    print("[EMBED] Generating Titan embedding for extracted text...")
    body = json.dumps({"inputText": text})
    resp = bedrock.invoke_model(modelId="amazon.titan-embed-text-v1", body=body)
    data = json.loads(resp["body"].read())
    vector = data["embedding"]
    print(f"[EMBED] Generated embedding with length={len(vector)}")
    return vector

def store_in_vector_index(key, vector, metadata):
    """Store embedding in S3 Vector index"""
    print(f"[STORE] Storing vector for '{key}' into S3 Vector index '{VECTOR_INDEX}'")
    s3vectors.put_vectors(
        bucketName=VECTOR_BUCKET,
        indexName=VECTOR_INDEX,
        vectors=[
            {"id": key, "values": vector, "metadata": metadata}
        ]
    )
    print(f"[STORE] ✅ Vector stored successfully for {key}")

def lambda_handler(event, context):
    """Main Lambda entrypoint"""
    for record in event["Records"]:
        bucket = record["s3"]["bucket"]["name"]
        key = record["s3"]["object"]["key"]

        text = extract_text(bucket, key)
        if not text.strip():
            print(f"[WARN] No text found in {key}, skipping.")
            continue

        vector = get_embedding(text)
        metadata = {"source_file": key}
        store_in_vector_index(key, vector, metadata)

        print(f"[DONE] ✅ Stored embedding for {key} (dim={len(vector)})")

    return {"statusCode": 200, "body": "Vectors stored successfully"}
