# Add this debug code to app_v2_fixed.py

# In search_resume_by_name function, after the query_vectors call:

resp = s3vector.query_vectors(
    vectorBucketName=VECTOR_BUCKET,
    indexName=VECTOR_INDEX,
    queryVector={"float32": search_embedding},
    topK=100
)

# ADD THIS DEBUG SECTION:
print(f"[DEBUG] ==================== QUERY RESPONSE DEBUG ====================")
print(f"[DEBUG] Response keys: {list(resp.keys())}")
print(f"[DEBUG] Response type: {type(resp)}")

# Try different possible keys for results
for key in ['matches', 'results', 'vectors', 'items']:
    if key in resp:
        print(f"[DEBUG] Found results in key: '{key}'")
        results_data = resp[key]
        print(f"[DEBUG] Number of results: {len(results_data)}")
        if len(results_data) > 0:
            print(f"[DEBUG] First result keys: {list(results_data[0].keys())}")
            print(f"[DEBUG] First result sample:")
            print(json.dumps(results_data[0], indent=2, default=str)[:1000])
        break

print(f"[DEBUG] ================================================================")

# Then continue with your existing code
results = resp.get("matches", resp.get("results", resp.get("vectors", [])))
