import os
import json
import boto3
import traceback

# ======== Environment Config ========
AWS_REGION = os.environ.get("AWS_REGION", "us-east-1")
VECTOR_BUCKET = os.environ.get("VECTOR_BUCKET")
VECTOR_INDEX = os.environ.get("VECTOR_INDEX")

print(f"[INIT] Loaded config: REGION={AWS_REGION}, VECTOR_BUCKET={VECTOR_BUCKET}, VECTOR_INDEX={VECTOR_INDEX}")

# ======== AWS Clients ========
s3 = boto3.client("s3", region_name=AWS_REGION)
textract = boto3.client("textract", region_name=AWS_REGION)
bedrock = boto3.client("bedrock-runtime", region_name=AWS_REGION)
s3vector = boto3.client("s3vectors", region_name=AWS_REGION)

# ======== Helper Functions ========

def extract_text(bucket, key):
    """Extracts text content from supported file types in S3."""
    print(f"[EXTRACT] Extracting text from s3://{bucket}/{key}")

    # Handle text files directly
    if key.lower().endswith(".txt"):
        tmp_path = f"/tmp/{os.path.basename(key)}"
        s3.download_file(bucket, key, tmp_path)
        with open(tmp_path, "r", encoding="utf-8") as f:
            text = f.read()
        print(f"[EXTRACT] Extracted {len(text)} characters from text file.")
        return text

    # Use Textract for PDF/DOCX
    try:
        response = textract.detect_document_text(
            Document={"S3Object": {"Bucket": bucket, "Name": key}}
        )
        lines = [b["Text"] for b in response["Blocks"] if b["BlockType"] == "LINE"]
        text = " ".join(lines)
        print(f"[EXTRACT] Extracted {len(lines)} lines of text from {key}")
        return text
    except Exception as e:
        print(f"[ERROR] Textract failed for {key}: {str(e)}")
        raise


def get_embedding(text):
    """Generates an embedding for the given text using Amazon Bedrock Titan."""
    print("[EMBED] Generating embedding using Titan model...")
    try:
        body = json.dumps({"inputText": text})
        response = bedrock.invoke_model(
            modelId="amazon.titan-embed-text-v1",
            body=body
        )
        data = json.loads(response["body"].read())
        vector = data["embedding"]
        print(f"[EMBED] Generated embedding of length={len(vector)}")
        return vector
    except Exception as e:
        print(f"[ERROR] Bedrock embedding failed: {str(e)}")
        raise


def store_in_vector_index(key, vector, metadata):
    """Stores the embedding into the S3 Vector Index."""
    print(f"[STORE] Storing vector for '{key}' in index '{VECTOR_INDEX}'...")
    try:
        s3vector.put_vectors(
            bucketName=VECTOR_BUCKET,
            indexName=VECTOR_INDEX,
            vectors=[
                {
                    "id": key,
                    "values": vector,
                    "metadata": metadata
                }
            ]
        )
        print(f"[STORE] ✅ Successfully stored vector for {key}")
    except Exception as e:
        print(f"[ERROR] Failed to store vector in S3 Vector Index: {str(e)}")
        raise


# ======== Lambda Handler ========

def lambda_handler(event, context):
    """Triggered by S3 upload events."""
    print(f"[EVENT] {json.dumps(event)}")

    try:
        for record in event.get("Records", []):
            bucket = record["s3"]["bucket"]["name"]
            key = record["s3"]["object"]["key"]

            print(f"[PROCESS] Processing file: s3://{bucket}/{key}")

            # Step 1: Extract text
            text = extract_text(bucket, key)
            if not text.strip():
                print(f"[WARN] No text extracted from {key}, skipping.")
                continue

            # Step 2: Generate embeddings
            vector = get_embedding(text)

            # Step 3: Store embeddings in S3 Vector Index
            metadata = {"source_file": key}
            store_in_vector_index(key, vector, metadata)

            print(f"[DONE] ✅ Stored embedding for {key} (dim={len(vector)})")

        return {"statusCode": 200, "body": "Vectors stored successfully"}

    except Exception as e:
        print("[FATAL] Lambda failed with exception:")
        print(traceback.format_exc())
        return {"statusCode": 500, "body": str(e)}
