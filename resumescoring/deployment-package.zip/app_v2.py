import os
import json
import boto3
import math
from typing import List, Dict, Optional
from pydantic import BaseModel, Field
from fastapi import FastAPI, HTTPException
from mangum import Mangum

app = FastAPI()

# -------- Environment Configuration --------
REGION = os.getenv("AWS_REGION", "us-east-2")
VECTOR_BUCKET = os.getenv("VECTOR_BUCKET")
VECTOR_INDEX = os.getenv("VECTOR_INDEX")
BEDROCK_EMBED_MODEL = os.getenv("BEDROCK_EMBED_MODEL", "amazon.titan-embed-text-v2:0")
BEDROCK_LLM_MODEL = os.getenv("BEDROCK_LLM_MODEL", "anthropic.claude-3-5-sonnet-20241022-v2:0")

print(f"[INIT] REGION={REGION}, VECTOR_BUCKET={VECTOR_BUCKET}, VECTOR_INDEX={VECTOR_INDEX}")
print(f"[INIT] EMBED_MODEL={BEDROCK_EMBED_MODEL}, LLM_MODEL={BEDROCK_LLM_MODEL}")

# Initialize AWS clients
bedrock = boto3.client("bedrock-runtime", region_name=REGION)
s3vector = boto3.client("s3vectors", region_name=REGION)

print("[INIT] Bedrock and S3 Vector clients initialized successfully.")


# -------- Request Models --------
class ResumeMatchRequest(BaseModel):
    resume_name: str = Field(..., description="Name/ID of the resume to match")
    job_description: str = Field(..., description="Job description text to match against")
    use_detailed_analysis: Optional[bool] = Field(default=False, description="Use Claude for detailed analysis")


# -------- Helper Functions --------

def get_embedding(text: str) -> List[float]:
    """Generate embedding using Amazon Titan."""
    print(f"[BEDROCK] Generating embedding for text: {text[:60]}...")
    
    body = {"inputText": text}
    response = bedrock.invoke_model(
        modelId=BEDROCK_EMBED_MODEL,
        body=json.dumps(body),
        accept="application/json",
        contentType="application/json"
    )
    
    result = json.loads(response["body"].read())
    print("[BEDROCK] Embedding generated successfully.")
    return result["embedding"]


def cosine_similarity(vec1: List[float], vec2: List[float]) -> float:
    """
    Calculate cosine similarity between two vectors using only Python built-ins.
    
    Args:
        vec1: First vector
        vec2: Second vector
    
    Returns:
        Cosine similarity score (0-1)
    """
    if not vec1 or not vec2:
        return 0.0
    
    if len(vec1) != len(vec2):
        print(f"[WARNING] Vector length mismatch: {len(vec1)} vs {len(vec2)}")
        return 0.0
    
    # Calculate dot product
    dot_product = sum(a * b for a, b in zip(vec1, vec2))
    
    # Calculate magnitudes (norms)
    magnitude1 = math.sqrt(sum(a * a for a in vec1))
    magnitude2 = math.sqrt(sum(b * b for b in vec2))
    
    # Avoid division by zero
    if magnitude1 == 0 or magnitude2 == 0:
        return 0.0
    
    # Calculate cosine similarity
    similarity = dot_product / (magnitude1 * magnitude2)
    
    # Ensure it's in [0, 1] range (sometimes floating point errors can cause slight overflow)
    similarity = max(0.0, min(1.0, similarity))
    
    return float(similarity)


def search_resume_by_name(resume_name: str) -> Optional[Dict]:
    """
    Search for a specific resume in S3 Vector index by name.
    Returns both the SKILLS vector and content chunks.
    
    Args:
        resume_name: Name or partial name of resume file
    
    Returns:
        Dictionary with skills_vector and content_chunks
    """
    print(f"[S3VECTOR] Searching for resume: {resume_name}")
    
    try:
        # List all vectors to find matching resume
        all_vectors = []
        next_token = None
        
        while True:
            if next_token:
                resp = s3vector.list_vectors(
                    vectorBucketName=VECTOR_BUCKET,
                    indexName=VECTOR_INDEX,
                    maxResults=100,
                    nextToken=next_token
                )
            else:
                resp = s3vector.list_vectors(
                    vectorBucketName=VECTOR_BUCKET,
                    indexName=VECTOR_INDEX,
                    maxResults=100
                )
            
            all_vectors.extend(resp.get("vectors", []))
            
            next_token = resp.get("nextToken")
            if not next_token:
                break
        
        # Filter for vectors matching resume name
        resume_name_lower = resume_name.lower()
        resume_name_clean = resume_name.replace('.pdf', '').replace('.docx', '').replace('/', '_')
        
        skills_vector = None
        content_chunks = []
        
        for vector in all_vectors:
            vector_key = vector.get('key', '')
            metadata = vector.get('metadata', {})
            file_name = metadata.get('file_name', '')
            
            # Check if this belongs to our resume
            if (resume_name_lower in vector_key.lower() or 
                resume_name_lower in file_name.lower() or
                resume_name_clean.lower() in vector_key.lower()):
                
                # Separate skills vector from content chunks
                if '_SKILLS' in vector_key:
                    skills_vector = {
                        'vector_id': vector_key,
                        'metadata': metadata,
                        'embedding': vector.get('data', {}).get('float32', [])
                    }
                elif metadata.get('type') == 'content':
                    content_chunks.append({
                        'vector_id': vector_key,
                        'metadata': metadata,
                        'embedding': vector.get('data', {}).get('float32', []),
                        'text': metadata.get('chunk_text', '')
                    })
        
        if not skills_vector:
            print(f"[S3VECTOR] ⚠️ No resume found matching: {resume_name}")
            return None
        
        print(f"[S3VECTOR] ✅ Found resume: {skills_vector['metadata'].get('name', 'Unknown')}")
        print(f"[S3VECTOR] ✅ Found {len(content_chunks)} content chunks")
        
        return {
            'skills_vector': skills_vector,
            'content_chunks': content_chunks
        }
        
    except Exception as e:
        print(f"[S3VECTOR] ❌ Error searching resume: {e}")
        import traceback
        traceback.print_exc()
        return None


def calculate_semantic_score(jd_text: str, jd_embedding: List[float], resume_data: Dict) -> Dict:
    """
    Calculate semantic similarity score between JD and resume.
    
    Args:
        jd_text: Job description text
        jd_embedding: JD embedding vector
        resume_data: Resume data with skills_vector and content_chunks
    
    Returns:
        Scoring breakdown with semantic similarity
    """
    print("[SCORING] Calculating semantic similarity scores...")
    
    skills_vector = resume_data['skills_vector']
    content_chunks = resume_data['content_chunks']
    
    # 1. Calculate similarity with skills vector
    skills_embedding = skills_vector.get('embedding', [])
    if skills_embedding:
        skills_similarity = cosine_similarity(jd_embedding, skills_embedding)
        print(f"[SCORING] Skills vector similarity: {skills_similarity:.4f}")
    else:
        skills_similarity = 0.0
        print("[SCORING] ⚠️ No skills embedding found")
    
    # 2. Calculate similarity with each content chunk
    chunk_similarities = []
    for chunk in content_chunks[:20]:  # Limit to top 20 chunks to avoid timeout
        chunk_embedding = chunk.get('embedding', [])
        if chunk_embedding:
            similarity = cosine_similarity(jd_embedding, chunk_embedding)
            chunk_similarities.append({
                'similarity': similarity,
                'text': chunk.get('text', '')[:200],  # First 200 chars
                'page': chunk.get('metadata', {}).get('page', 'unknown')
            })
    
    # Sort chunks by similarity
    chunk_similarities.sort(key=lambda x: x['similarity'], reverse=True)
    
    # 3. Calculate average content similarity (from top 5 chunks)
    if chunk_similarities:
        top_chunks = chunk_similarities[:5]
        avg_content_similarity = sum(c['similarity'] for c in top_chunks) / len(top_chunks)
        max_content_similarity = chunk_similarities[0]['similarity']
        print(f"[SCORING] Average content similarity (top 5): {avg_content_similarity:.4f}")
        print(f"[SCORING] Max content similarity: {max_content_similarity:.4f}")
    else:
        avg_content_similarity = 0.0
        max_content_similarity = 0.0
        print("[SCORING] ⚠️ No content chunks found")
    
    # 4. Extract skills from metadata
    metadata = skills_vector['metadata']
    resume_skills = set()
    for key in ['tech_skills', 'cloud_skills', 'devops_tools']:
        skills_str = metadata.get(key, '')
        skills = [s.strip().lower() for s in skills_str.split(',') if s.strip()]
        resume_skills.update(skills)
    
    # 5. Simple skill extraction from JD (just for basic matching)
    import re
    jd_words = set(re.findall(r'\b[A-Za-z][A-Za-z0-9+#\.]{2,}\b', jd_text.lower()))
    matched_skills = resume_skills.intersection(jd_words)
    skill_overlap = len(matched_skills) / len(jd_words) if jd_words else 0
    
    print(f"[SCORING] Skill overlap: {skill_overlap:.4f} ({len(matched_skills)} matched)")
    
    # 6. Calculate weighted final score
    # 50% skills vector similarity, 30% content similarity, 20% skill overlap
    final_score = (
        0.50 * skills_similarity +
        0.30 * avg_content_similarity +
        0.20 * skill_overlap
    )
    
    # Convert to 0-100 scale
    final_score_pct = int(final_score * 100)
    
    print(f"[SCORING] ✅ Final Score: {final_score_pct}/100")
    
    return {
        "overall_score": final_score_pct,
        "semantic_score": round(final_score, 4),
        "skills_vector_similarity": round(skills_similarity, 4),
        "avg_content_similarity": round(avg_content_similarity, 4),
        "max_content_similarity": round(max_content_similarity, 4),
        "skill_overlap_score": round(skill_overlap, 4),
        "matched_skills": list(matched_skills)[:20],  # Top 20 matched skills
        "top_matching_chunks": [
            {
                "similarity": round(c['similarity'], 4),
                "text_snippet": c['text'],
                "page": c['page']
            }
            for c in chunk_similarities[:3]  # Top 3 chunks
        ],
        "scoring_breakdown": {
            "skills_weight": "50%",
            "content_weight": "30%",
            "overlap_weight": "20%"
        }
    }


def get_detailed_analysis_with_claude(jd_text: str, resume_metadata: Dict, semantic_scores: Dict) -> Dict:
    """
    Use Claude to provide detailed hiring recommendation based on semantic scores.
    
    Args:
        jd_text: Job description text
        resume_metadata: Resume metadata from S3 Vector
        semantic_scores: Calculated semantic scores
    
    Returns:
        Detailed analysis from Claude
    """
    print("[CLAUDE] Getting detailed analysis...")
    
    prompt = f"""You are an expert recruiter. Based on the semantic similarity analysis below, provide a hiring recommendation.

Job Description:
{jd_text[:1000]}...

Candidate Profile:
- Name: {resume_metadata.get('name', 'Unknown')}
- Title: {resume_metadata.get('title', '')}
- Experience: {resume_metadata.get('years_exp', '')} years
- Technical Skills: {resume_metadata.get('tech_skills', '')}
- Cloud Skills: {resume_metadata.get('cloud_skills', '')}
- DevOps Tools: {resume_metadata.get('devops_tools', '')}

Semantic Similarity Analysis:
- Overall Score: {semantic_scores['overall_score']}/100
- Skills Vector Similarity: {semantic_scores['skills_vector_similarity']}
- Content Similarity: {semantic_scores['avg_content_similarity']}
- Skill Overlap: {semantic_scores['skill_overlap_score']}

Top Matching Content:
{json.dumps(semantic_scores['top_matching_chunks'], indent=2)}

Provide your analysis in JSON format (no markdown):
{{
    "recommendation": "Strong Match|Good Match|Moderate Match|Weak Match",
    "confidence_level": "High|Medium|Low",
    "strengths": ["List 2-3 key strengths"],
    "concerns": ["List 1-2 concerns if any"],
    "hiring_decision": "Recommend|Consider|Pass",
    "justification": "2-3 sentence explanation"
}}"""

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1000,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.3
    }
    
    try:
        response = bedrock.invoke_model(
            modelId=BEDROCK_LLM_MODEL,
            body=json.dumps(body)
        )
        
        result = json.loads(response['body'].read())
        content = result['content'][0]['text']
        
        # Clean JSON
        content = content.strip()
        if '```json' in content:
            content = content.split('```json')[1].split('```')[0]
        elif '```' in content:
            content = content.split('```')[1].split('```')[0]
        
        content = content.strip()
        analysis = json.loads(content)
        
        print(f"[CLAUDE] ✅ Analysis complete: {analysis.get('recommendation', 'N/A')}")
        return analysis
        
    except Exception as e:
        print(f"[CLAUDE] ⚠️ Error getting analysis: {e}")
        return {
            "recommendation": "See Scores",
            "confidence_level": "N/A",
            "strengths": ["High semantic similarity score"],
            "concerns": ["Manual review recommended"],
            "hiring_decision": "Review Required",
            "justification": f"Semantic score: {semantic_scores['overall_score']}/100. Claude analysis unavailable."
        }


# -------- API Endpoints --------

@app.post("/match-resume")
async def match_resume(request: ResumeMatchRequest):
    """
    Match a specific resume against a job description using semantic similarity.
    
    This is the main endpoint for Bedrock Agent:
    - Takes resume_name and job_description
    - Retrieves resume from S3 Vector (processed by PDFDOCReader)
    - Calculates semantic similarity scores
    - Optionally provides detailed Claude analysis
    
    Returns comprehensive scoring and analysis.
    """
    print(f"\n{'='*80}")
    print(f"[API] Processing Resume Match Request")
    print(f"      Resume: {request.resume_name}")
    print(f"      JD Length: {len(request.job_description)} chars")
    print(f"      Detailed Analysis: {request.use_detailed_analysis}")
    print(f"{'='*80}\n")
    
    try:
        # Step 1: Search for resume in S3 Vector
        print("[STEP 1] Searching for resume in S3 Vector...")
        resume_data = search_resume_by_name(request.resume_name)
        
        if not resume_data:
            raise HTTPException(
                status_code=404,
                detail=f"Resume not found: {request.resume_name}. Make sure it was processed by PDFDOCReader lambda."
            )
        
        skills_vector = resume_data['skills_vector']
        metadata = skills_vector['metadata']
        
        # Step 2: Generate JD embedding
        print("[STEP 2] Generating job description embedding...")
        jd_embedding = get_embedding(request.job_description)
        
        # Step 3: Calculate semantic similarity scores
        print("[STEP 3] Calculating semantic similarity scores...")
        semantic_scores = calculate_semantic_score(
            request.job_description,
            jd_embedding,
            resume_data
        )
        
        # Step 4: Get detailed analysis if requested
        detailed_analysis = None
        if request.use_detailed_analysis:
            print("[STEP 4] Getting detailed Claude analysis...")
            detailed_analysis = get_detailed_analysis_with_claude(
                request.job_description,
                metadata,
                semantic_scores
            )
        
        # Prepare response
        result = {
            "status": "success",
            "resume_info": {
                "name": metadata.get("name", "Unknown"),
                "title": metadata.get("title", ""),
                "years_experience": metadata.get("years_exp", ""),
                "email": metadata.get("email", ""),
                "phone": metadata.get("phone", ""),
                "file_name": metadata.get("file_name", ""),
                "s3_uri": metadata.get("s3_uri", ""),
                "technical_skills": metadata.get("tech_skills", "").split(",")[:10],
                "cloud_skills": metadata.get("cloud_skills", "").split(",")[:10],
                "devops_tools": metadata.get("devops_tools", "").split(",")[:10]
            },
            "match_scores": semantic_scores
        }
        
        if detailed_analysis:
            result["detailed_analysis"] = detailed_analysis
        
        print(f"\n{'='*80}")
        print(f"[SUCCESS] Match Complete")
        print(f"          Overall Score: {semantic_scores['overall_score']}/100")
        print(f"          Semantic Score: {semantic_scores['semantic_score']}")
        if detailed_analysis:
            print(f"          Recommendation: {detailed_analysis.get('recommendation', 'N/A')}")
        print(f"{'='*80}\n")
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"[ERROR] {str(e)}")
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "resume-matcher-v2",
        "region": REGION,
        "vector_bucket": VECTOR_BUCKET,
        "vector_index": VECTOR_INDEX
    }


# -------- Lambda Handler --------
asgi_handler = Mangum(app)


def lambda_handler(event, context):
    """
    Hybrid handler supporting both:
    - API Gateway (via Mangum/FastAPI)
    - Bedrock Agent Function calls (messageVersion 1.0)
    """
    print("\n" + "="*80)
    print("[LAMBDA] Handler Invoked")
    print("="*80)
    print(f"[EVENT] {json.dumps(event, default=str)}")
    
    try:
        # Check if this is a Bedrock Agent function call
        if "messageVersion" in event and "function" in event:
            print("[LAMBDA] Detected Bedrock Agent invocation")
            
            function_name = event.get("function")
            params = event.get("parameters", [])
            
            # Extract parameters
            resume_name = next((p["value"] for p in params if p["name"] == "resume_name"), None)
            job_description = next((p["value"] for p in params if p["name"] == "job_description"), None)
            use_detailed = next((p["value"] for p in params if p["name"] == "use_detailed_analysis"), "false")
            
            if not resume_name or not job_description:
                raise ValueError("Missing required parameters: resume_name and job_description")
            
            # Convert string to boolean
            use_detailed_bool = use_detailed.lower() in ['true', '1', 'yes']
            
            # Create request object
            request = ResumeMatchRequest(
                resume_name=resume_name,
                job_description=job_description,
                use_detailed_analysis=use_detailed_bool
            )
            
            print(f"[LAMBDA] Processing: {resume_name}")
            print(f"[LAMBDA] JD Length: {len(job_description)}")
            print(f"[LAMBDA] Detailed Analysis: {use_detailed_bool}")
            
            # Execute the matching function
            import asyncio
            loop = asyncio.get_event_loop()
            result = loop.run_until_complete(match_resume(request))
            
            print(f"[LAMBDA] Match completed successfully")
            print(f"[LAMBDA] Score: {result['match_scores']['overall_score']}/100")
            
            return {
                "messageVersion": "1.0",
                "response": {
                    "actionGroup": event.get("actionGroup"),
                    "function": function_name,
                    "functionResponse": {
                        "responseBody": {
                            "TEXT": {
                                "body": json.dumps(result, indent=2)
                            }
                        }
                    }
                }
            }
        
        # Otherwise, delegate to FastAPI via Mangum
        print("[LAMBDA] Delegating to FastAPI via Mangum...")
        return asgi_handler(event, context)
        
    except Exception as e:
        print(f"[LAMBDA][ERROR] {str(e)}")
        import traceback
        traceback.print_exc()
        
        error_response = {
            "error": str(e),
            "error_type": type(e).__name__
        }
        
        if "messageVersion" in event:
            return {
                "messageVersion": "1.0",
                "response": {
                    "actionGroup": event.get("actionGroup", ""),
                    "function": event.get("function", ""),
                    "functionResponse": {
                        "responseBody": {
                            "TEXT": {
                                "body": json.dumps(error_response)
                            }
                        }
                    }
                }
            }
        else:
            return {
                "statusCode": 500,
                "body": json.dumps(error_response)
            }
    
    finally:
        print("="*80)
        print("[LAMBDA] Handler Completed")
        print("="*80 + "\n")


handler = lambda_handler
