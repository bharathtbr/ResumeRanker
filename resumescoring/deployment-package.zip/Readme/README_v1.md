# Resume Ranking App v1 - AI-Powered Resume Matching

## Overview

`app_v1.py` is an advanced resume matching system that uses AWS Bedrock AI models to intelligently match resumes against job descriptions. It reads resume data from S3 Vector storage and provides comprehensive matching analysis.

## Key Features

### 🎯 Intelligent Skill Extraction
- Uses **Claude 3.5 Sonnet** to extract skills from job descriptions
- Identifies must-have vs nice-to-have skills
- Extracts technical skills, cloud platforms, tools, and certifications

### 📊 Advanced Matching Algorithm
- **Bedrock-powered scoring**: Uses Claude for intelligent match analysis
- **Semantic similarity**: Vector-based resume search using Titan embeddings
- **Multi-factor scoring**:
  - Overall match score (0-100)
  - Skill match percentage
  - Experience alignment
  - Tool proficiency match

### 🔍 Dual Search Capabilities
1. **Single Resume Match**: Match a specific resume against a JD
2. **Multi-Resume Search**: Find top N candidates for a job description

## Architecture

```
┌─────────────────┐
│  Bedrock Agent  │
│   or API Call   │
└────────┬────────┘
         │
         ▼
┌─────────────────────────────────────┐
│        app_v1.py (Lambda)           │
│  ┌──────────────────────────────┐   │
│  │  FastAPI + Mangum Handler    │   │
│  └──────────────┬───────────────┘   │
│                 │                    │
│  ┌──────────────▼───────────────┐   │
│  │   Claude 3.5 Sonnet          │   │
│  │   (Skill Extraction)         │   │
│  └──────────────┬───────────────┘   │
│                 │                    │
│  ┌──────────────▼───────────────┐   │
│  │   S3 Vector Search           │   │
│  │   (Resume Retrieval)         │   │
│  └──────────────┬───────────────┘   │
│                 │                    │
│  ┌──────────────▼───────────────┐   │
│  │   Titan Embeddings           │   │
│  │   (Semantic Search)          │   │
│  └──────────────┬───────────────┘   │
│                 │                    │
│  ┌──────────────▼───────────────┐   │
│  │   Claude Scoring Engine      │   │
│  │   (Match Analysis)           │   │
│  └──────────────────────────────┘   │
└─────────────────────────────────────┘
```

## Environment Variables

Set these in your Lambda configuration:

```bash
AWS_REGION=us-east-2                                          # AWS region
VECTOR_BUCKET=your-vector-bucket                              # S3 Vector bucket name
VECTOR_INDEX=resume-index                                     # Vector index name
BEDROCK_EMBED_MODEL=amazon.titan-embed-text-v2:0             # Embedding model
BEDROCK_LLM_MODEL=anthropic.claude-3-5-sonnet-20241022-v2:0  # LLM model
```

## API Endpoints

### 1. Match Single Resume

**Endpoint**: `POST /match-resume`

Match a specific resume against a job description.

**Request**:
```json
{
  "resume_name": "john_doe_resume.pdf",
  "job_description": "We are looking for a Senior Python Developer with 5+ years experience in AWS, Docker, and Kubernetes...",
  "top_k": 5
}
```

**Response**:
```json
{
  "status": "success",
  "resume_info": {
    "name": "John Doe",
    "title": "Senior Software Engineer",
    "years_experience": "7",
    "email": "john.doe@email.com",
    "file_name": "john_doe_resume.pdf",
    "s3_uri": "s3://bucket/john_doe_resume.pdf"
  },
  "job_requirements": {
    "title": "Senior Python Developer",
    "experience_required": "5",
    "must_have_skills": ["Python", "AWS", "Docker"],
    "nice_to_have_skills": ["React", "GraphQL"]
  },
  "match_analysis": {
    "overall_score": 85,
    "skill_match_score": 90,
    "experience_match_score": 80,
    "tool_match_score": 85,
    "matched_skills": ["Python", "AWS", "Docker", "Kubernetes"],
    "missing_critical_skills": [],
    "missing_nice_to_have": ["React"],
    "strengths": [
      "Strong cloud experience with AWS",
      "Proficient in containerization"
    ],
    "concerns": [
      "Missing React experience"
    ],
    "recommendation": "Strong Match",
    "justification": "Candidate has all must-have skills and exceeds experience requirements"
  }
}
```

### 2. Search Multiple Resumes

**Endpoint**: `POST /search-resumes`

Find top N candidates for a job description.

**Request**:
```json
{
  "resume_name": "",  
  "job_description": "We are looking for a Senior Python Developer with 5+ years experience in AWS, Docker, and Kubernetes...",
  "top_k": 10
}
```

**Response**:
```json
{
  "status": "success",
  "job_requirements": {
    "title": "Senior Python Developer",
    "must_have_skills": ["Python", "AWS", "Docker"],
    "nice_to_have_skills": ["React", "GraphQL"]
  },
  "total_results": 10,
  "candidates": [
    {
      "candidate_name": "John Doe",
      "title": "Senior Software Engineer",
      "years_experience": "7",
      "email": "john.doe@email.com",
      "file_name": "john_doe_resume.pdf",
      "overall_score": 85,
      "recommendation": "Strong Match",
      "matched_skills": ["Python", "AWS", "Docker", "Kubernetes"],
      "missing_skills": [],
      "strengths": ["Strong cloud experience"],
      "concerns": ["Missing React"]
    },
    ...
  ]
}
```

## Bedrock Agent Integration

The Lambda handler automatically detects Bedrock Agent invocations:

**Agent Action Schema**:
```json
{
  "function": "match_resume",
  "parameters": [
    {
      "name": "resume_name",
      "type": "string",
      "description": "Name or ID of the resume file",
      "required": true
    },
    {
      "name": "job_description",
      "type": "string",
      "description": "Full job description text",
      "required": true
    }
  ]
}
```

## How It Works

### Step-by-Step Process

#### For Single Resume Matching:

1. **JD Skill Extraction**
   - Claude analyzes the job description
   - Extracts technical requirements, experience level, certifications
   - Categorizes skills into must-have and nice-to-have

2. **Resume Retrieval**
   - Searches S3 Vector index for the specified resume
   - Retrieves resume metadata (skills, experience, certifications)
   - Uses the `_SKILLS` vector created by PDFDOCReader lambda

3. **Match Score Calculation**
   - Claude compares JD requirements with candidate profile
   - Provides multi-dimensional scoring:
     - Skill match (technical, cloud, tools)
     - Experience alignment
     - Certification matches
   - Identifies strengths and concerns
   - Provides hiring recommendation

4. **Response Generation**
   - Comprehensive analysis with actionable insights
   - Lists matched and missing skills
   - Provides justification for the score

#### For Multiple Resume Search:

1. **JD Embedding**
   - Generates Titan embedding for the job description
   
2. **Semantic Search**
   - Queries S3 Vector index for top K similar resumes
   - Filters for `_SKILLS` vectors only

3. **Batch Scoring**
   - Scores each candidate using Claude
   - Ranks by overall match score

4. **Ranked Results**
   - Returns sorted list of candidates
   - Each with detailed match analysis

## Deployment

### 1. Package Dependencies

```bash
cd A2-Laymbda
pip install -r requirements_v1.txt -t package/
cp app_v1.py package/
cd package
zip -r ../app_v1.zip .
```

### 2. Create Lambda Function

```bash
aws lambda create-function \
  --function-name resume-matcher-v1 \
  --runtime python3.11 \
  --role arn:aws:iam::ACCOUNT_ID:role/lambda-execution-role \
  --handler app_v1.handler \
  --zip-file fileb://app_v1.zip \
  --timeout 300 \
  --memory-size 1024 \
  --environment Variables="{
    AWS_REGION=us-east-2,
    VECTOR_BUCKET=your-vector-bucket,
    VECTOR_INDEX=resume-index,
    BEDROCK_EMBED_MODEL=amazon.titan-embed-text-v2:0,
    BEDROCK_LLM_MODEL=anthropic.claude-3-5-sonnet-20241022-v2:0
  }"
```

### 3. Add API Gateway Trigger

```bash
aws apigatewayv2 create-api \
  --name resume-matcher-api \
  --protocol-type HTTP \
  --target arn:aws:lambda:REGION:ACCOUNT_ID:function:resume-matcher-v1
```

## IAM Permissions Required

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel"
      ],
      "Resource": [
        "arn:aws:bedrock:*::foundation-model/amazon.titan-embed-text-v2:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-5-sonnet-20241022-v2:0"
      ]
    },
    {
      "Effect": "Allow",
      "Action": [
        "s3vectors:QueryVectors",
        "s3vectors:ListVectors"
      ],
      "Resource": "arn:aws:s3vectors:*:*:vector-bucket/your-vector-bucket/index/resume-index"
    }
  ]
}
```

## Testing

### Local Testing with FastAPI

```bash
uvicorn app_v1:app --reload --host 0.0.0.0 --port 8000
```

Then test with curl:

```bash
# Match single resume
curl -X POST http://localhost:8000/match-resume \
  -H "Content-Type: application/json" \
  -d '{
    "resume_name": "john_doe.pdf",
    "job_description": "Looking for Senior Python Developer with AWS experience..."
  }'

# Search multiple resumes
curl -X POST http://localhost:8000/search-resumes \
  -H "Content-Type: application/json" \
  -d '{
    "resume_name": "",
    "job_description": "Looking for Senior Python Developer with AWS experience...",
    "top_k": 5
  }'
```

### Lambda Testing

Create test event:

```json
{
  "messageVersion": "1.0",
  "function": "match_resume",
  "actionGroup": "resume-matcher",
  "parameters": [
    {
      "name": "resume_name",
      "type": "string",
      "value": "john_doe_resume.pdf"
    },
    {
      "name": "job_description",
      "type": "string",
      "value": "We are looking for a Senior Python Developer with 5+ years experience in AWS, Docker, and Kubernetes. Must have strong problem-solving skills and experience leading teams."
    }
  ]
}
```

## Key Differences from app.py

| Feature | app.py | app_v1.py |
|---------|--------|-----------|
| Skill Extraction | Regex-based | Claude AI-based |
| Data Source | PostgreSQL | S3 Vector Storage |
| Scoring | Mathematical formula | Claude AI analysis |
| Search | SQL queries | Vector similarity |
| Resume Access | Database query | S3 Vector metadata |
| Match Quality | Basic overlap | Multi-dimensional AI scoring |

## Advantages

1. **No Database Dependency**: Uses S3 Vector storage directly
2. **AI-Powered Analysis**: Claude provides human-like matching insights
3. **Better Skill Extraction**: Claude understands context and synonyms
4. **Semantic Search**: Finds similar resumes even with different terminology
5. **Comprehensive Scoring**: Multi-factor analysis with justification
6. **Scalable**: S3 Vector scales automatically

## Limitations

1. **Cost**: Bedrock API calls incur costs
2. **Latency**: AI processing takes longer than database queries
3. **Token Limits**: Very long resumes may be truncated
4. **Dependency**: Requires resumes to be processed by PDFDOCReader first

## Monitoring

Monitor these CloudWatch metrics:
- `Duration`: Lambda execution time
- `Errors`: Failed invocations
- `Bedrock API Calls`: Number of Bedrock invocations
- `S3 Vector Queries`: Vector search operations

## Troubleshooting

### Resume Not Found
- Ensure resume was processed by PDFDOCReader lambda
- Check if `_SKILLS` vector exists in S3 Vector index
- Verify resume_name matches file name in metadata

### Low Match Scores
- Verify JD has clear skill requirements
- Check if resume has skill data in metadata
- Review Claude's justification for insights

### Timeout Errors
- Increase Lambda timeout (recommend 300 seconds)
- Reduce top_k for search-resumes endpoint
- Consider batch processing for large-scale searches

## Future Enhancements

- [ ] Add caching for repeated JD queries
- [ ] Implement skill synonym matching
- [ ] Add experience level validation
- [ ] Support multiple JD formats (JSON, YAML)
- [ ] Add confidence scores for each match dimension
- [ ] Implement feedback loop for scoring improvement

## License

MIT License - See LICENSE file for details
