# 🐛 Debugging Guide - 0 Content Chunks & "Unknown" Name

## Issues Found

Based on your logs:
```
[S3VECTOR] Found SKILLS vector: T-Bharath 16+ Exp - Secops-AWS,Azure,Architect,SRE,Devops-av_SKILLS
[S3VECTOR] ✅ Found 0 content chunks  ← PROBLEM 1
[S3VECTOR] ✅ Found resume: Unknown  ← PROBLEM 2
```

## Problem 1: 0 Content Chunks

### Root Cause:
The PDFDOCReader processed the DOCX file but didn't create content chunk vectors.

### Possible Reasons:

**A. Text extraction failed**
```python
# In PDFDOCReader, line ~474
full_text = extract_docx_text(file_bytes)
# This might return empty string
```

**B. Text was empty after extraction**
```python
if not text.strip():
    continue  # Skips chunk creation
```

**C. Batch wasn't flushed**
```python
if batch:
    store_vector_batch(batch)  # This might not run
```

### Debug Steps:

#### 1. Check PDFDOCReader CloudWatch Logs

Look for:
```
📥 Processing: s3://bucket/T-Bharath 16+ Exp - Secops-AWS,Azure,Architect,SRE,Devops-av.docx
```

Then check if you see:
```
💾 Storing batch of X vectors...  ← Should see this multiple times
```

If you DON'T see "Storing batch", the chunking failed.

#### 2. Add Debug Logging to PDFDOCReader

After line 479, add:
```python
elif key.lower().endswith(".docx"):
    full_text = extract_docx_text(file_bytes)
    pages = [{"page_number": 1, "text": full_text}]
    
    # ADD THIS:
    print(f"[DEBUG] DOCX extracted {len(full_text)} characters")
    print(f"[DEBUG] First 200 chars: {full_text[:200]}")
```

After line 508, add:
```python
chunks = chunk_text(text)

# ADD THIS:
print(f"[DEBUG] Created {len(chunks)} chunks from page {page_num}")
```

#### 3. Test DOCX Extraction Locally

```python
import docx2txt
import tempfile

# Read your DOCX file
with open('T-Bharath 16+ Exp - Secops-AWS,Azure,Architect,SRE,Devops-av.docx', 'rb') as f:
    file_bytes = f.read()

# Extract text
with tempfile.NamedTemporaryFile(suffix=".docx") as tmp:
    tmp.write(file_bytes)
    tmp.flush()
    text = docx2txt.process(tmp.name)

print(f"Extracted {len(text)} characters")
print(f"First 500 chars:\n{text[:500]}")

# Test chunking
words = text.split()
print(f"\nTotal words: {len(words)}")
print(f"Expected chunks: {len(words) // 800}")
```

## Problem 2: Resume Name Shows "Unknown"

### Root Cause:
The metadata in the SKILLS vector has `"name": "Unknown"`

This means:
1. **Claude failed to extract the name** during PDFDOCReader processing
2. OR the metadata field is actually empty/missing

### Check Actual Metadata:

Add logging to app_v2_fixed.py at line ~175:

```python
skills_vector = {
    'vector_id': vector_key,
    'metadata': metadata,
    'embedding': vector.get('data', {}).get('float32', [])
}
print(f"[S3VECTOR] Found SKILLS vector: {vector_key}")

# ADD THIS:
print(f"[DEBUG] Full metadata: {json.dumps(metadata, indent=2)}")
```

This will show you EXACTLY what's in the metadata.

## Quick Fix for app_v2_fixed.py

The issue is that app_v2_fixed is looking at `metadata.get('name')` but it should handle the case where metadata is empty or incomplete.

### Updated Code:

Replace the section starting at line ~252 in app_v2_fixed.py:

```python
# OLD CODE:
metadata = skills_vector['metadata']

# NEW CODE:
metadata = skills_vector.get('metadata', {})

# Debug: Print what we got
print(f"[DEBUG] Metadata keys: {list(metadata.keys())}")
print(f"[DEBUG] Name: {metadata.get('name', 'NOT FOUND')}")
print(f"[DEBUG] Title: {metadata.get('title', 'NOT FOUND')}")
print(f"[DEBUG] Tech Skills: {metadata.get('tech_skills', 'NOT FOUND')}")
```

## Complete Debug Version

I'll create a debug version of app_v2_fixed that prints everything:

### Add to app_v2_fixed.py after line ~150:

```python
# After finding the SKILLS vector
if '_SKILLS' in vector_key:
    skills_vector = {
        'vector_id': vector_key,
        'metadata': metadata,
        'embedding': vector.get('data', {}).get('float32', [])
    }
    print(f"[S3VECTOR] Found SKILLS vector: {vector_key}")
    
    # ADD DETAILED DEBUG:
    print(f"[DEBUG] ==================== SKILLS VECTOR METADATA ====================")
    print(f"[DEBUG] Vector has {len(metadata)} metadata fields")
    for key, value in metadata.items():
        if isinstance(value, str) and len(value) > 100:
            print(f"[DEBUG]   {key}: {value[:100]}... (truncated)")
        else:
            print(f"[DEBUG]   {key}: {value}")
    print(f"[DEBUG] ================================================================")
```

## Test Query to Verify Metadata

Use AWS CLI to check what's actually stored:

```bash
# This won't work directly with s3vectors, but you can list vectors
aws lambda invoke \
  --function-name PDFDOCReader \
  --log-type Tail \
  --query 'LogResult' \
  --output text | base64 --decode
```

## Most Likely Solution

Based on the logs, I suspect:

### Issue 1: DOCX Not Creating Content Chunks
**Fix:** The DOCX might have complex formatting. Try:

1. Re-save the DOCX as a simpler format
2. OR convert to PDF first
3. OR check if docx2txt is working

### Issue 2: Metadata Not Populated
**Fix:** Claude extraction might have failed. Check PDFDOCReader logs for:

```
⚠️ Error extracting skills: ...
```

If you see this, the metadata will be:
```python
{
    "name": "Unknown",  ← This is why you see "Unknown"
    "email": "",
    "title": "",
    ...
}
```

## Quick Test

Upload a simple test resume:

1. Create test.docx with just:
   ```
   John Doe
   john@example.com
   
   Skills: Python, AWS, Docker
   
   Experience: 5 years as Software Engineer
   ```

2. Upload to S3
3. Check PDFDOCReader logs
4. Check if content chunks are created

## Next Steps

1. **Check PDFDOCReader logs** - Look for text extraction output
2. **Add debug logging** - See what metadata is actually stored
3. **Test with simple DOCX** - Rule out file corruption
4. **Re-process the file** - Upload again to trigger PDFDOCReader

Would you like me to create:
1. A debug version of PDFDOCReader with extensive logging?
2. A debug version of app_v2_fixed with metadata inspection?
3. A test script to validate DOCX extraction locally?
