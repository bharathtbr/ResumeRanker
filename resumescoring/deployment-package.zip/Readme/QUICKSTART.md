# 🚀 Quick Start Guide - app_v2.py

## Prerequisites
- Resume processed by PDFDOCReader lambda
- S3 Vector index set up
- AWS credentials configured

## 1. Install Dependencies

```bash
cd A2-Laymbda
pip install -r requirements_v2.txt
```

## 2. Set Environment Variables

```bash
export AWS_REGION=us-east-2
export VECTOR_BUCKET=your-s3-vector-bucket
export VECTOR_INDEX=resume-index
export BEDROCK_EMBED_MODEL=amazon.titan-embed-text-v2:0
export BEDROCK_LLM_MODEL=anthropic.claude-3-5-sonnet-20241022-v2:0
```

Or create `.env` file:
```
AWS_REGION=us-east-2
VECTOR_BUCKET=your-s3-vector-bucket
VECTOR_INDEX=resume-index
```

## 3. Test Locally

### Start the server
```bash
uvicorn app_v2:app --reload --port 8000
```

### Test with curl
```bash
curl -X POST http://localhost:8000/match-resume \
  -H "Content-Type: application/json" \
  -d '{
    "resume_name": "bharath_reddy_resume.pdf",
    "job_description": "Senior Python Developer with AWS and Docker experience",
    "use_detailed_analysis": false
  }'
```

### Test with Python script
```bash
python test_app_v2.py
```

## 4. Verify Resume Exists

Before testing, verify your resume was processed:

```python
import boto3

s3vector = boto3.client('s3vectors', region_name='us-east-2')

# List all vectors
response = s3vector.list_vectors(
    vectorBucketName='your-bucket',
    indexName='resume-index',
    maxResults=100
)

# Look for your resume
for vector in response['vectors']:
    print(f"Vector: {vector['key']}")
    if 'bharath_reddy' in vector['key'].lower():
        print(f"  ✅ Found: {vector['key']}")
        print(f"  Metadata: {vector.get('metadata', {})}")
```

## 5. Expected Response

```json
{
  "status": "success",
  "resume_info": {
    "name": "Bharath Reddy Thippaiahgari",
    "title": "Engineering Manager",
    "years_experience": "4",
    "email": "bharath@example.com",
    "technical_skills": ["Python", "C#", ".NET", "AWS", "Docker"],
    "cloud_skills": ["AWS", "Azure"],
    "devops_tools": ["Kubernetes", "Terraform", "Jenkins"]
  },
  "match_scores": {
    "overall_score": 86,
    "semantic_score": 0.8623,
    "skills_vector_similarity": 0.8912,
    "avg_content_similarity": 0.8534,
    "max_content_similarity": 0.9145,
    "skill_overlap_score": 0.7823,
    "matched_skills": ["python", "aws", "docker", "kubernetes"],
    "top_matching_chunks": [
      {
        "similarity": 0.9145,
        "text_snippet": "Led migration of monolith apps to microservices...",
        "page": "1"
      }
    ],
    "scoring_breakdown": {
      "skills_weight": "50%",
      "content_weight": "30%",
      "overlap_weight": "20%"
    }
  }
}
```

## 6. Deploy to Lambda

### Create deployment package
```bash
mkdir package
cd package
pip install -r ../requirements_v2.txt -t .
cp ../app_v2.py .
zip -r ../app_v2_lambda.zip .
cd ..
```

### Create Lambda function
```bash
aws lambda create-function \
  --function-name resume-matcher-semantic \
  --runtime python3.11 \
  --role arn:aws:iam::ACCOUNT:role/lambda-execution-role \
  --handler app_v2.handler \
  --zip-file fileb://app_v2_lambda.zip \
  --timeout 180 \
  --memory-size 1024 \
  --environment Variables="{
    AWS_REGION=us-east-2,
    VECTOR_BUCKET=your-vector-bucket,
    VECTOR_INDEX=resume-index
  }"
```

### Test Lambda
```bash
aws lambda invoke \
  --function-name resume-matcher-semantic \
  --payload file://test_event.json \
  response.json

cat response.json
```

test_event.json:
```json
{
  "messageVersion": "1.0",
  "function": "match_resume",
  "parameters": [
    {
      "name": "resume_name",
      "value": "bharath_reddy_resume.pdf"
    },
    {
      "name": "job_description",
      "value": "Senior Python Developer with AWS experience"
    }
  ]
}
```

## 7. Integrate with Bedrock Agent

### Create Action Group

In Bedrock Agent console:

1. Create new Action Group
2. Add function definition:
```json
{
  "name": "match_resume",
  "description": "Match resume against job description",
  "parameters": {
    "resume_name": {
      "description": "Resume file name",
      "type": "string",
      "required": true
    },
    "job_description": {
      "description": "Job description text",
      "type": "string",
      "required": true
    }
  }
}
```
3. Link to Lambda function: `resume-matcher-semantic`
4. Test in Agent console

## 8. Common Issues

### Resume Not Found
```
Error: Resume not found: bharath_reddy_resume.pdf
```
**Fix:** 
- Verify resume was processed by PDFDOCReader
- Check spelling of resume_name
- Try partial name: "bharath_reddy" instead of full filename

### No Embeddings
```
Warning: No skills embedding found
```
**Fix:**
- Resume's SKILLS vector is missing
- Re-process resume with PDFDOCReader
- Verify S3 Vector index has data

### Low Scores
```
Overall Score: 23/100
```
**Fix:**
- Check if JD and resume are actually similar
- Review matched_skills to see what matched
- Check top_matching_chunks to understand content similarity
- May be a genuine mismatch

## 9. Scoring Tips

### Good Score (80+)
- Resume matches JD requirements well
- Skills vector is highly similar
- Content chunks have relevant experience
- Strong keyword overlap

### Moderate Score (60-79)
- Partial match with JD
- Some skills missing
- Content is somewhat related
- Consider as potential candidate

### Low Score (<60)
- Poor match with JD
- Different skill sets
- Content doesn't align
- Likely not a good fit

## 10. Next Steps

✅ Test with your actual resumes
✅ Adjust score weights if needed (in app_v2.py)
✅ Enable detailed_analysis for top candidates
✅ Monitor Lambda logs in CloudWatch
✅ Set up alarms for errors
✅ Document your Bedrock Agent prompts

## Need Help?

1. Check logs: `CloudWatch → Log Groups → /aws/lambda/resume-matcher-semantic`
2. Test locally first before deploying
3. Verify environment variables
4. Ensure IAM permissions are correct
5. Review README_v2.md for detailed documentation

## Quick Troubleshooting

```bash
# Check if FastAPI is running
curl http://localhost:8000/health

# Test with simple request
curl -X POST http://localhost:8000/match-resume \
  -H "Content-Type: application/json" \
  -d '{"resume_name": "test.pdf", "job_description": "test"}'

# View Lambda logs
aws logs tail /aws/lambda/resume-matcher-semantic --follow

# List S3 Vectors
python -c "
import boto3
s3v = boto3.client('s3vectors', region_name='us-east-2')
r = s3v.list_vectors(vectorBucketName='BUCKET', indexName='INDEX', maxResults=10)
for v in r['vectors']: print(v['key'])
"
```

## Success Checklist

- [ ] Dependencies installed
- [ ] Environment variables set
- [ ] Resume exists in S3 Vector
- [ ] Local testing works
- [ ] Lambda deployed successfully
- [ ] Bedrock Agent configured
- [ ] End-to-end test passed

**You're ready to go! 🎉**
