# Check PDFDOCReader Logs for Metadata Storage

## What to Look For

In your PDFDOCReader CloudWatch logs, search for:

```
[SKILL_VECTOR] Metadata prepared:
```

You should see something like:

```
[SKILL_VECTOR] 💎 Creating skill vector for: T Bharath...
[SKILL_VECTOR] Metadata prepared:
[SKILL_VECTOR]   type: skills
[SKILL_VECTOR]   name: Bharath Reddy Thippaiahgari
[SKILL_VECTOR]   email: bharath@example.com
[SKILL_VECTOR]   title: Engineering Manager
[SKILL_VECTOR]   tech_skills: Python,C#,.NET,AWS...
[SKILL_VECTOR]   cloud_skills: AWS,Azure
```

## If You DON'T See This

The metadata was never stored in the first place!

## Possible Causes:

### 1. PDFDOCReader is Using OLD Version

Check if your PDFDOCReader is the debug version with metadata logging:

```bash
aws logs filter-log-events \
  --log-group-name /aws/lambda/PDFDOCReader \
  --filter-pattern "[SKILL_VECTOR]" \
  --start-time $(date -d '1 hour ago' +%s)000
```

If you see NOTHING, you're using the old version without proper metadata storage.

### 2. Metadata Exceeded 5KB Limit

S3 Vector has a 5KB metadata limit. If the metadata was too large, it might have been rejected.

Look for errors like:
```
[SKILL_VECTOR] ❌ ERROR storing skill vector: Metadata too large
```

### 3. S3 Vector API Changed

The metadata format might be different than expected.

## CRITICAL TEST

Let's manually check what's actually in your S3 Vector index.

### Check with PDFDOCReader's search_index function:

The PDFDOCReader has a working `search_index` function. Let's see what IT returns:

```python
# In PDFDOCReader lambda_function.py:

def search_index(query_text, top_k=3):
    query_vec = get_embedding(query_text)
    
    resp = s3vector.query_vectors(
        vectorBucketName=VECTOR_BUCKET,
        indexName=VECTOR_INDEX,
        queryVector={"float32": query_vec},
        topK=top_k
    )
    
    results = resp.get("matches", resp.get("results", resp.get("vectors", [])))
    
    # ADD THIS DEBUG:
    for i, r in enumerate(results):
        print(f"Result {i}:")
        print(f"  Keys: {list(r.keys())}")
        print(f"  Metadata: {r.get('metadata', 'NO METADATA KEY')}")
        if 'metadata' in r:
            print(f"  Metadata type: {type(r['metadata'])}")
            print(f"  Metadata content: {r['metadata']}")
    
    return results
```

Run this in PDFDOCReader and see what the metadata looks like.

## Most Likely Issue: Metadata Was Never Stored

Based on your logs showing "Metadata fields: 0" consistently, I suspect:

**The vectors were created WITHOUT metadata!**

This could happen if:
1. The original PDFDOCReader didn't have the metadata code
2. Metadata storage failed silently
3. The S3 Vector API changed

## Solution: Re-upload Resume

1. **Deploy the DEBUG version of PDFDOCReader** (`lambda_function_debug.py`)
2. **Delete the old resume from S3** (to trigger re-processing)
3. **Upload the resume again**
4. **Check CloudWatch logs** for metadata storage confirmation

You should see:
```
[SKILL_VECTOR] Metadata prepared:
[SKILL_VECTOR]   name: Bharath Reddy...
[SKILL_VECTOR]   tech_skills: .NET,C#,Python...
[SKILL_VECTOR] ✅ Skill vector stored successfully
```

Then check app_v2 logs again - you should see metadata!

## Alternative: Use Different Metadata Storage

If S3 Vector metadata isn't working, we can:
1. Store metadata in DynamoDB
2. Store metadata in S3 as JSON files
3. Embed metadata in the vector key itself

But first, let's confirm if metadata was EVER stored in the first place!
