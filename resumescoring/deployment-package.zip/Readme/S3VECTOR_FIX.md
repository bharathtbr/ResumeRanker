# 🔧 Fixing S3Vector Error - Quick Guide

## Problem
```
UnknownServiceError: Unknown service: 's3vectors'
```

## Solution 1: Update Boto3 (Most Likely Fix) ⭐

### In Lambda Deployment Package:

```bash
cd A2-Laymbda

# Create package with latest boto3
mkdir package
cd package

# Install latest boto3
pip install boto3==1.35.0 --upgrade -t .

# Install other dependencies
pip install -r ../requirements_v2.txt -t .

# Copy your app
cp ../app_v2_fixed.py app_v2.py

# Create zip
zip -r ../lambda_package.zip .
```

### Upload to Lambda:

```bash
aws lambda update-function-code \
  --function-name resume-matcher-semantic \
  --zip-file fileb://lambda_package.zip
```

## Solution 2: Add IAM Permissions

Your Lambda execution role needs:

```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Sid": "S3VectorAccess",
      "Effect": "Allow",
      "Action": [
        "s3vectors:ListVectors",
        "s3vectors:PutVectors",
        "s3vectors:QueryVectors",
        "s3vectors:GetVector",
        "s3vectors:DeleteVectors"
      ],
      "Resource": "*"
    },
    {
      "Sid": "S3TablesAccess",
      "Effect": "Allow",
      "Action": [
        "s3tables:GetTableBucket",
        "s3tables:ListTableBuckets"
      ],
      "Resource": "*"
    },
    {
      "Sid": "BedrockAccess",
      "Effect": "Allow",
      "Action": [
        "bedrock:InvokeModel"
      ],
      "Resource": [
        "arn:aws:bedrock:*::foundation-model/amazon.titan-embed-text-v2:0",
        "arn:aws:bedrock:*::foundation-model/anthropic.claude-3-5-sonnet-20241022-v2:0"
      ]
    },
    {
      "Sid": "CloudWatchLogs",
      "Effect": "Allow",
      "Action": [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents"
      ],
      "Resource": "arn:aws:logs:*:*:*"
    }
  ]
}
```

### Apply via AWS Console:

1. Go to IAM → Roles
2. Find your Lambda execution role (e.g., `resume-matcher-role`)
3. Click "Add permissions" → "Create inline policy"
4. Paste the JSON above
5. Name it `S3VectorAndBedrockPolicy`
6. Save

### Or via CLI:

```bash
# Save JSON to file
cat > lambda-policy.json << 'EOF'
{
  "Version": "2012-10-17",
  "Statement": [...]
}
EOF

# Attach to role
aws iam put-role-policy \
  --role-name resume-matcher-role \
  --policy-name S3VectorAndBedrockPolicy \
  --policy-document file://lambda-policy.json
```

## Solution 3: Check Region

S3 Tables is in **preview** - only available in:
- ✅ us-east-1 (N. Virginia)
- ✅ us-west-2 (Oregon)  
- ✅ eu-west-1 (Ireland)

If your Lambda is in **us-east-2**, you have two options:

**Option A: Move to us-east-1**
```bash
# Recreate Lambda in us-east-1
export AWS_REGION=us-east-1

# Then redeploy
```

**Option B: Use Cross-Region**
```python
# In app_v2_fixed.py, change:
s3vector = boto3.client("s3vectors", region_name="us-east-1")  # Force us-east-1
```

## Quick Test

```python
# test_s3vector.py
import boto3

try:
    client = boto3.client('s3vectors', region_name='us-east-1')
    print("✅ S3Vector client works!")
    print(f"Boto3 version: {boto3.__version__}")
except Exception as e:
    print(f"❌ Error: {e}")
    print(f"Boto3 version: {boto3.__version__}")
    print("Run: pip install boto3 --upgrade")
```

## What You Should See in CloudWatch

### Success:
```
[INIT] ✅ S3 Vector client initialized successfully.
[S3VECTOR] Searching for resume: bharath_reddy_resume.pdf
[S3VECTOR] Retrieved 15 vectors
[S3VECTOR] ✅ Found resume: Bharath Reddy
```

### Failure:
```
[INIT] ⚠️ WARNING: Could not initialize s3vectors client
[INIT] This may be due to:
[INIT]   1. Boto3 version too old
[INIT]   2. Missing IAM permissions
[INIT]   3. S3 Tables not available in this region
```

## Files to Use

- ✅ **app_v2_fixed.py** - Has better error handling
- ✅ **requirements_v2.txt** - Correct dependencies

## Deployment Command

```bash
# Full deployment script
cd A2-Laymbda

# Clean start
rm -rf package lambda_package.zip

# Create package
mkdir package && cd package

# Install dependencies with latest boto3
pip install boto3==1.35.0 -t .
pip install fastapi==0.110.0 -t .
pip install mangum==0.17.0 -t .
pip install pydantic==2.6.0 -t .

# Copy app (use fixed version)
cp ../app_v2_fixed.py app_v2.py

# Create zip
zip -r ../lambda_package.zip .
cd ..

# Upload
aws lambda update-function-code \
  --function-name resume-matcher-semantic \
  --zip-file fileb://lambda_package.zip

# Set environment variables
aws lambda update-function-configuration \
  --function-name resume-matcher-semantic \
  --environment Variables="{
    AWS_REGION=us-east-1,
    VECTOR_BUCKET=your-vector-bucket,
    VECTOR_INDEX=resume-index,
    BEDROCK_EMBED_MODEL=amazon.titan-embed-text-v2:0,
    BEDROCK_LLM_MODEL=anthropic.claude-3-5-sonnet-20241022-v2:0
  }"

# Test
aws lambda invoke \
  --function-name resume-matcher-semantic \
  --payload file://test-event.json \
  response.json

cat response.json
```

## test-event.json

```json
{
  "messageVersion": "1.0",
  "function": "match_resume",
  "actionGroup": "ResumeMatchingGroup",
  "parameters": [
    {
      "name": "resume_name",
      "type": "string",
      "value": "bharath_reddy_resume.pdf"
    },
    {
      "name": "job_description",
      "type": "string",
      "value": "Senior Python Developer with 5+ years experience in AWS, Docker, and Kubernetes"
    }
  ]
}
```

## Still Not Working?

1. **Check PDFDOCReader first:**
   ```bash
   aws logs tail /aws/lambda/PDFDOCReader --follow
   ```
   Make sure it creates vectors successfully

2. **Verify boto3 version:**
   ```bash
   # In Lambda, add this to your code:
   import boto3
   print(f"Boto3 version: {boto3.__version__}")
   # Should be >= 1.34.0
   ```

3. **Check available services:**
   ```python
   import boto3
   session = boto3.Session()
   print(session.get_available_services())
   # Look for 's3vectors' in the list
   ```

4. **Use app_v2_fixed.py:**
   It has detailed error logging that will help diagnose the issue

## Summary

Most likely fix: **Update boto3 to latest version**

```bash
pip install boto3 --upgrade
```

Then redeploy your Lambda with the updated package.
