# 🐛 CRITICAL FIX: Metadata is Empty

## Problem Identified

Looking at your logs:

```
[DEBUG] Total metadata fields: 0
[DEBUG] name: NOT_FOUND
[DEBUG] email: NOT_FOUND
```

**The metadata dictionary is EMPTY even though the vector exists!**

## Root Cause

S3 Vector's `list_vectors()` API **does not return metadata by default**. You need to use `get_vector()` or `describe_vector()` to retrieve the actual metadata.

## The Fix

### Option 1: Use get_vector() to Retrieve Full Metadata

Replace the section in `app_v2_fixed.py` around line 140-180:

```python
# OLD CODE (doesn't get metadata):
for vector in all_vectors:
    vector_key = vector.get('key', '')
    metadata = vector.get('metadata', {})  # ← This returns EMPTY!
    
# NEW CODE (retrieves metadata):
for vector in all_vectors:
    vector_key = vector.get('key', '')
    
    # Get full vector with metadata
    try:
        full_vector_resp = s3vector.get_vector(
            vectorBucketName=VECTOR_BUCKET,
            indexName=VECTOR_INDEX,
            key=vector_key
        )
        metadata = full_vector_resp.get('metadata', {})
    except Exception as e:
        print(f"[S3VECTOR] Warning: Could not get metadata for {vector_key}: {e}")
        metadata = {}
```

### Option 2: Query Instead of List

Instead of listing all vectors, use query_vectors which returns full results:

```python
def search_resume_by_name(resume_name: str) -> Optional[Dict]:
    """Search for resume using query instead of list."""
    print(f"[S3VECTOR] Searching for resume: {resume_name}")
    
    if not s3vector:
        raise Exception("S3 Vector client not initialized")
    
    try:
        # Generate a dummy embedding for search
        dummy_text = f"Resume for {resume_name}"
        search_embedding = get_embedding(dummy_text)
        
        # Query to get vectors with metadata
        resp = s3vector.query_vectors(
            vectorBucketName=VECTOR_BUCKET,
            indexName=VECTOR_INDEX,
            queryVector={"float32": search_embedding},
            topK=100  # Get more results
        )
        
        results = resp.get("matches", resp.get("results", []))
        
        resume_name_lower = resume_name.lower()
        
        skills_vector = None
        content_chunks = []
        
        for result in results:
            vector_key = result.get('key', '')
            metadata = result.get('metadata', {})  # Query returns metadata!
            
            # Check if this belongs to our resume
            if resume_name_lower in vector_key.lower():
                if '_SKILLS' in vector_key:
                    skills_vector = {
                        'vector_id': vector_key,
                        'metadata': metadata,
                        'embedding': result.get('vector', {}).get('float32', [])
                    }
                    print(f"[S3VECTOR] Found SKILLS vector: {vector_key}")
                    print(f"[DEBUG] Metadata fields: {len(metadata)}")
                    for key in ['name', 'email', 'title']:
                        print(f"[DEBUG]   {key}: {metadata.get(key, 'MISSING')}")
                elif metadata.get('type') == 'content':
                    content_chunks.append({
                        'vector_id': vector_key,
                        'metadata': metadata,
                        'embedding': result.get('vector', {}).get('float32', []),
                        'text': metadata.get('chunk_text', '')
                    })
        
        if not skills_vector:
            return None
            
        return {
            'skills_vector': skills_vector,
            'content_chunks': content_chunks
        }
        
    except Exception as e:
        print(f"[S3VECTOR] Error: {e}")
        traceback.print_exc()
        raise
```

## Quick Test

To verify if metadata is actually stored, try this AWS CLI command:

```bash
# This won't work directly, but check PDFDOCReader logs
# Look for this in PDFDOCReader CloudWatch logs:

[SKILL_VECTOR] Metadata prepared:
[SKILL_VECTOR]   name: Bharath
[SKILL_VECTOR]   tech_skills: Python,AWS...

# If you see this, metadata WAS stored
# If you don't see this, metadata was NOT stored
```

## Immediate Action

1. **Check PDFDOCReader logs** - Look for `[SKILL_VECTOR] Metadata prepared:`
2. **If you see metadata in PDFDOCReader logs**, the issue is in app_v2 retrieval
3. **If you DON'T see metadata in PDFDOCReader logs**, the issue is in storage

## Most Likely Issue

Based on your logs showing `Total metadata fields: 0`, the S3 Vector `list_vectors()` API is **not returning metadata**.

**Solution:** Use `query_vectors()` or `get_vector()` to retrieve full vector data including metadata.

## Updated app_v2_fixed.py

I'll create a version that uses get_vector() to retrieve metadata properly.
