# FINAL FIX - The metadata IS stored, but we're reading the response wrong!

## The Problem

PDFDOCReader stores metadata correctly (line 215-238 in lambda_function.py).
BUT app_v2 shows "Metadata fields: 0" when reading it back.

This means the S3 Vector response format is different than we expected!

## The Correct Fix

The issue is in HOW we're reading the query response. Let me check PDFDOCReader's search_by_skills function (line 349-417) - it also uses `list_vectors()` and accesses metadata directly from `vector.get('metadata', {})`.

This suggests that:
1. `list_vectors()` DOES return metadata
2. OR there's a different way to access it

## Updated search_resume_by_name Function

Replace the entire function with this version that matches PDFDOCReader's pattern exactly:

```python
def search_resume_by_name(resume_name: str) -> Optional[Dict]:
    """
    Search for a specific resume using the EXACT same pattern as PDFDOCReader.
    """
    print(f"[S3VECTOR] Searching for resume: {resume_name}")
    
    if not s3vector:
        raise Exception("S3 Vector client not initialized")
    
    try:
        # Step 1: List ALL vectors (same as PDFDOCReader's search_by_skills)
        print(f"[S3VECTOR] Listing all vectors...")
        all_vectors = []
        next_token = None
        
        while True:
            if next_token:
                resp = s3vector.list_vectors(
                    vectorBucketName=VECTOR_BUCKET,
                    indexName=VECTOR_INDEX,
                    maxResults=100,
                    nextToken=next_token
                )
            else:
                resp = s3vector.list_vectors(
                    vectorBucketName=VECTOR_BUCKET,
                    indexName=VECTOR_INDEX,
                    maxResults=100
                )
            
            all_vectors.extend(resp.get("vectors", []))
            
            next_token = resp.get("nextToken")
            if not next_token:
                break
        
        print(f"[S3VECTOR] Retrieved {len(all_vectors)} total vectors")
        
        # Step 2: Filter for our resume (same pattern as PDFDOCReader)
        resume_name_lower = resume_name.lower()
        resume_name_clean = resume_name.replace('.pdf', '').replace('.docx', '').replace('/', '_')
        
        skills_vector = None
        content_chunks = []
        
        for vector in all_vectors:
            vector_key = vector.get('key', '')
            
            # CRITICAL: Try accessing metadata the EXACT same way as PDFDOCReader
            metadata = vector.get('metadata', {})
            
            # DEBUG: Print what we're getting
            print(f"[DEBUG] Vector: {vector_key[:50]}...")
            print(f"[DEBUG] Vector keys: {list(vector.keys())}")
            print(f"[DEBUG] Metadata type: {type(metadata)}")
            print(f"[DEBUG] Metadata: {metadata}")
            
            file_name = metadata.get('file_name', '')
            
            # Check if this belongs to our resume
            if (resume_name_lower in vector_key.lower() or 
                resume_name_lower in file_name.lower() or
                resume_name_clean.lower() in vector_key.lower()):
                
                print(f"[S3VECTOR] ✅ Matched: {vector_key}")
                
                if '_SKILLS' in vector_key:
                    skills_vector = {
                        'vector_id': vector_key,
                        'metadata': metadata,
                        'embedding': vector.get('data', {}).get('float32', [])
                    }
                    print(f"[S3VECTOR] Found SKILLS vector")
                    print(f"[DEBUG] Metadata fields: {len(metadata)}")
                    
                    # Print ALL keys in metadata
                    for k in metadata.keys():
                        print(f"[DEBUG]   {k}: {metadata[k]}")
                        
                elif metadata.get('type') == 'content':
                    content_chunks.append({
                        'vector_id': vector_key,
                        'metadata': metadata,
                        'embedding': vector.get('data', {}).get('float32', []),
                        'text': metadata.get('chunk_text', '')
                    })
        
        if not skills_vector:
            return None
            
        print(f"[S3VECTOR] ✅ Found {len(content_chunks)} content chunks")
        
        return {
            'skills_vector': skills_vector,
            'content_chunks': content_chunks
        }
        
    except Exception as e:
        print(f"[S3VECTOR] ❌ Error: {e}")
        import traceback
        traceback.print_exc()
        raise
```

## This Will Tell Us:

The debug output will show:
1. What keys are in each vector object
2. What type metadata is (dict, None, etc.)
3. The actual metadata content

Then we'll know EXACTLY how to access it!

## Deploy and Test

1. Replace search_resume_by_name in app_v2_fixed.py
2. Redeploy
3. Test again
4. Check logs for the DEBUG output

The debug will tell us the exact structure!
