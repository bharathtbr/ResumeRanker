import os
import uuid
import json
import boto3
import psycopg2
import re
from psycopg2.extras import Json
from pydantic import BaseModel
from fastapi import FastAPI, HTTPException
from mangum import Mangum
from sentence_transformers import SentenceTransformer, util

# Use same model for semantic similarity
model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")

app = FastAPI()

# -------- Environment Configuration --------
DB_NAME = os.getenv("PG_DB", "resumes")
DB_USER = os.getenv("PG_USER", "bharat")
DB_PASS = os.getenv("PG_PASS", "bharat@123")
DB_HOST = os.getenv("PG_HOST", "165.227.21.40")
DB_PORT = os.getenv("PG_PORT", "5432")
REGION = os.getenv("AWS_REGION", "us-east-2")

print(f"[INIT] Loaded config: DB={DB_NAME}@{DB_HOST}:{DB_PORT}, REGION={REGION}")

# Bedrock client
bedrock = boto3.client("bedrock-runtime", region_name=REGION)
print("[INIT] Bedrock client initialized successfully.")

class SearchRequest(BaseModel):
    query: str
# -------- Helpers --------
def get_connection():
    print("[DB] Opening PostgreSQL connection...")
    conn = psycopg2.connect(
        dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT
    )
    print("[DB] Connection established.")
    return conn


def embedding_for(text: str):
    print(f"[BEDROCK] Generating embedding for text: {text[:60]}...")
    body = json.dumps({"inputText": text})
    resp = bedrock.invoke_model(
        modelId=os.getenv("BEDROCK_MODEL_ID", "amazon.titan-embed-text-v2:0"),
        body=body,
        accept="application/json",
        contentType="application/json",
    )
    result = json.loads(resp["body"].read())
    print("[BEDROCK] Embedding generated successfully.")
    return result["embedding"]


def extract_skills(text):
    skills = list(set(re.findall(r'\b[A-Z][a-zA-Z]+\b', text)))
    print(f"[SKILLS] Extracted {skills}")
    return skills

def query_resumes(query: str, top_k: int = 10):
    """Search resumes by semantic similarity using pgvector."""
    query_emb = embed_model.encode(query).tolist()
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute(
            f"""
            SELECT id, filename, skills, content,
                   1 - (embedding <=> %s::vector) AS similarity
            FROM resume_data.resumes
            ORDER BY embedding <=> %s::vector
            LIMIT %s;
            """,
            (query_emb, query_emb, top_k),
        )
        results = cur.fetchall()
    return results

def compute_final_score(jd_text, jd_skills, resume_text, resume_skills_list, dist):
    semantic_score = float(util.cos_sim(model.encode(jd_text, normalize_embeddings=True),
                                        model.encode(resume_text, normalize_embeddings=True)).item())
    overlap = len(set(resume_skills_list) & set(jd_skills)) / len(jd_skills) if jd_skills else 0
    emb_score = 1 - dist
    final_score = round(0.4 * emb_score + 0.4 * semantic_score + 0.2 * overlap, 4)
    return {
        "score": final_score,
        "embedding_similarity": round(emb_score, 4),
        "semantic_similarity": round(semantic_score, 4),
        "skill_overlap": round(overlap, 4),
        "matched_skills": list(set(resume_skills_list) & set(jd_skills)),
        "missing_skills": list(set(jd_skills) - set(resume_skills_list)),
        "snippet": (resume_text[:500] + "...") if len(resume_text) > 500 else resume_text
    }


def search_resume(req: SearchRequest):
    jd_text = req.query.strip()
    if not jd_text:
        return {"status": "empty query"}
    #jd_emb = embedding_for(jd_text)
    jd_skills = extract_skills(jd_text)

    resumes = query_resumes(jd_text, top_k=10)
    hits = []
    for r in resumes:
        resume_skills = [s.strip() for s in r["skills"].split(",") if s.strip()]
        score_dict = compute_final_score(jd_text, jd_skills,  r["content"], resume_skills, dist=0.1)
        hits.append({"filename": r["filename"], **score_dict})

    hits = sorted(hits, key=lambda x: x["score"], reverse=True)
    return {"JD_Skills": jd_skills, "results": hits}

# -------- Hybrid Handler --------
asgi_handler = Mangum(app)


def lambda_handler(event, context):
    """
    Handles both:
    - API Gateway (via Mangum)
    - Bedrock Agent Function (messageVersion 1.0)
    """
    print("========== [LAMBDA HANDLER START] ==========")
    print(f"[EVENT] {json.dumps(event)}")

    try:
        # 🧩 Bedrock Agent function event
        if "messageVersion" in event and "function" in event:
            print("[LAMBDA] Detected Bedrock Agent invocation format.")
            params = event.get("parameters", [])
            query_param = next((p["value"] for p in params if p["name"] == "query"), None)
            if not query_param:
                raise ValueError("Missing 'query' parameter in event.")

            result = search_resume(query_param)
            print(f"[LAMBDA] JD insertion result: {result}")

            return {
                "messageVersion": "1.0",
                "response": {
                    "content": [
                        {
                            "contentType": "application/json",
                            "body": json.dumps(result),
                        }
                    ]
                },
            }

        # 🌐 API Gateway Event (via Mangum)
        print("[LAMBDA] Delegating to FastAPI via Mangum...")
        return asgi_handler(event, context)

    except Exception as e:
        print(f"[LAMBDA][ERROR] {str(e)}")
        return {
            "messageVersion": "1.0",
            "response": {
                "content": [
                    {
                        "contentType": "text/plain",
                        "body": f"Error: {str(e)}",
                    }
                ]
            },
        }
    finally:
        print("========== [LAMBDA HANDLER END] ==========")


handler = lambda_handler
