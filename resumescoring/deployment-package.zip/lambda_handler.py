from app_prod import lambda_handler

handler = lambda_handler
