import os
import uuid
import json
import boto3
import re
from typing import List, Dict, Optional
from pydantic import BaseModel, Field
from fastapi import FastAPI, HTTPException
from mangum import Mangum

app = FastAPI()

# -------- Environment Configuration --------
REGION = os.getenv("AWS_REGION", "us-east-2")
VECTOR_BUCKET = os.getenv("VECTOR_BUCKET")
VECTOR_INDEX = os.getenv("VECTOR_INDEX")
BEDROCK_EMBED_MODEL = os.getenv("BEDROCK_EMBED_MODEL", "amazon.titan-embed-text-v2:0")
BEDROCK_LLM_MODEL = os.getenv("BEDROCK_LLM_MODEL", "anthropic.claude-3-5-sonnet-20241022-v2:0")

print(f"[INIT] REGION={REGION}, VECTOR_BUCKET={VECTOR_BUCKET}, VECTOR_INDEX={VECTOR_INDEX}")
print(f"[INIT] EMBED_MODEL={BEDROCK_EMBED_MODEL}, LLM_MODEL={BEDROCK_LLM_MODEL}")

# Initialize AWS clients
bedrock = boto3.client("bedrock-runtime", region_name=REGION)
s3vector = boto3.client("s3vectors", region_name=REGION)

print("[INIT] Bedrock and S3 Vector clients initialized successfully.")


# -------- Request Models --------
class ResumeMatchRequest(BaseModel):
    resume_name: str = Field(..., description="Name/ID of the resume to match")
    job_description: str = Field(..., description="Job description text to match against")
    top_k: Optional[int] = Field(default=5, description="Number of top results to return")


# -------- Helper Functions --------

def get_embedding(text: str) -> List[float]:
    """Generate embedding using Amazon Titan."""
    print(f"[BEDROCK] Generating embedding for text: {text[:60]}...")
    
    body = {"inputText": text}
    response = bedrock.invoke_model(
        modelId=BEDROCK_EMBED_MODEL,
        body=json.dumps(body),
        accept="application/json",
        contentType="application/json"
    )
    
    result = json.loads(response["body"].read())
    print("[BEDROCK] Embedding generated successfully.")
    return result["embedding"]


def extract_skills_with_claude(text: str, text_type: str = "job description") -> Dict:
    """
    Extract skills from job description or resume using Claude.
    
    Args:
        text: The text to extract skills from
        text_type: Type of text ("job description" or "resume")
    
    Returns:
        Dictionary with extracted skills and metadata
    """
    print(f"[CLAUDE] Extracting skills from {text_type}...")
    
    # Truncate if too long
    max_chars = 15000
    if len(text) > max_chars:
        text = text[:max_chars] + "... [truncated]"
    
    if text_type.lower() == "job description":
        prompt = f"""Analyze this job description and extract key requirements. Return ONLY a compact JSON object (no markdown, no explanations).

Job Description:
{text}

Extract:
{{
    "job_title": "Position Title",
    "experience_required": "5",
    "technical_skills": ["Python", "Java", "AWS"],
    "cloud_platforms": ["AWS", "Azure"],
    "tools": ["Docker", "Kubernetes", "Jenkins"],
    "databases": ["PostgreSQL", "MongoDB"],
    "soft_skills": ["Leadership", "Communication"],
    "certifications": ["AWS Certified Solutions Architect"],
    "key_responsibilities": ["Design systems", "Lead team"],
    "must_have_skills": ["Python", "AWS", "SQL"],
    "nice_to_have_skills": ["React", "GraphQL"]
}}

Keep arrays under 10 items each. Return ONLY valid JSON."""
    
    else:  # resume
        prompt = f"""Analyze this resume and extract key information. Return ONLY a compact JSON object (no markdown, no explanations).

Resume:
{text}

Extract:
{{
    "name": "Full Name",
    "email": "email@example.com",
    "current_title": "Current Job Title",
    "years_experience": "5",
    "technical_skills": ["Python", "Java", "JavaScript"],
    "cloud_platforms": ["AWS", "Azure", "GCP"],
    "tools": ["Docker", "Kubernetes", "Jenkins"],
    "databases": ["PostgreSQL", "MongoDB"],
    "certifications": ["AWS Certified Solutions Architect"],
    "top_companies": ["Google", "Amazon"],
    "key_achievements": ["Led team of 10", "Reduced costs by 30%"]
}}

Keep arrays under 10 items each. Return ONLY valid JSON."""

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 2000,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.1
    }
    
    try:
        response = bedrock.invoke_model(
            modelId=BEDROCK_LLM_MODEL,
            body=json.dumps(body)
        )
        
        result = json.loads(response['body'].read())
        content = result['content'][0]['text']
        
        # Clean JSON from markdown
        content = content.strip()
        if '```json' in content:
            content = content.split('```json')[1].split('```')[0]
        elif '```' in content:
            content = content.split('```')[1].split('```')[0]
        
        content = content.strip()
        extracted_data = json.loads(content)
        
        print(f"[CLAUDE] ✅ Extracted skills from {text_type}")
        return extracted_data
        
    except Exception as e:
        print(f"[CLAUDE] ⚠️ Error extracting skills: {e}")
        return {
            "error": str(e),
            "technical_skills": [],
            "cloud_platforms": [],
            "tools": []
        }


def search_resume_by_name(resume_name: str) -> Optional[Dict]:
    """
    Search for a specific resume in S3 Vector index by name.
    
    Args:
        resume_name: Name or partial name of resume file
    
    Returns:
        Resume data with metadata or None if not found
    """
    print(f"[S3VECTOR] Searching for resume: {resume_name}")
    
    try:
        # List all vectors to find matching resume
        all_vectors = []
        next_token = None
        
        while True:
            if next_token:
                resp = s3vector.list_vectors(
                    vectorBucketName=VECTOR_BUCKET,
                    indexName=VECTOR_INDEX,
                    maxResults=100,
                    nextToken=next_token
                )
            else:
                resp = s3vector.list_vectors(
                    vectorBucketName=VECTOR_BUCKET,
                    indexName=VECTOR_INDEX,
                    maxResults=100
                )
            
            all_vectors.extend(resp.get("vectors", []))
            
            next_token = resp.get("nextToken")
            if not next_token:
                break
        
        # Filter for skill vectors that match resume name
        resume_name_lower = resume_name.lower()
        matching_vectors = []
        
        for vector in all_vectors:
            vector_key = vector.get('key', '')
            metadata = vector.get('metadata', {})
            file_name = metadata.get('file_name', '')
            
            # Check if this is a skill vector and matches the resume name
            if '_SKILLS' in vector_key and (
                resume_name_lower in vector_key.lower() or 
                resume_name_lower in file_name.lower()
            ):
                matching_vectors.append({
                    'vector_id': vector_key,
                    'metadata': metadata,
                    'vector_data': vector.get('data', {})
                })
        
        if not matching_vectors:
            print(f"[S3VECTOR] ⚠️ No resume found matching: {resume_name}")
            return None
        
        # Return the first match (most likely the skill vector)
        resume_data = matching_vectors[0]
        print(f"[S3VECTOR] ✅ Found resume: {resume_data['metadata'].get('name', 'Unknown')}")
        
        return resume_data
        
    except Exception as e:
        print(f"[S3VECTOR] ❌ Error searching resume: {e}")
        return None


def semantic_search_resumes(query_embedding: List[float], top_k: int = 5) -> List[Dict]:
    """
    Perform semantic search on resume vectors.
    
    Args:
        query_embedding: Embedding vector for the query
        top_k: Number of results to return
    
    Returns:
        List of matching resumes with scores
    """
    print(f"[S3VECTOR] Performing semantic search with topK={top_k}")
    
    try:
        resp = s3vector.query_vectors(
            vectorBucketName=VECTOR_BUCKET,
            indexName=VECTOR_INDEX,
            queryVector={"float32": query_embedding},
            topK=top_k * 3  # Get more to filter skill vectors
        )
        
        results = resp.get("matches", resp.get("results", resp.get("vectors", [])))
        
        # Filter for skill vectors only
        skill_results = []
        for result in results:
            vector_key = result.get('key', '')
            if '_SKILLS' in vector_key:
                skill_results.append(result)
                if len(skill_results) >= top_k:
                    break
        
        print(f"[S3VECTOR] ✅ Found {len(skill_results)} matching skill vectors")
        return skill_results
        
    except Exception as e:
        print(f"[S3VECTOR] ❌ Error in semantic search: {e}")
        return []


def calculate_match_score_with_bedrock(jd_data: Dict, resume_metadata: Dict) -> Dict:
    """
    Calculate comprehensive match score using Claude for intelligent analysis.
    
    Args:
        jd_data: Extracted job description data
        resume_metadata: Resume metadata from S3 Vector
    
    Returns:
        Detailed scoring breakdown
    """
    print("[CLAUDE] Calculating match score...")
    
    # Prepare data for Claude
    jd_summary = {
        "title": jd_data.get("job_title", ""),
        "experience_required": jd_data.get("experience_required", ""),
        "must_have_skills": jd_data.get("must_have_skills", []),
        "technical_skills": jd_data.get("technical_skills", []),
        "cloud_platforms": jd_data.get("cloud_platforms", []),
        "tools": jd_data.get("tools", [])
    }
    
    resume_summary = {
        "name": resume_metadata.get("name", ""),
        "title": resume_metadata.get("title", ""),
        "years_exp": resume_metadata.get("years_exp", ""),
        "tech_skills": resume_metadata.get("tech_skills", "").split(","),
        "cloud_skills": resume_metadata.get("cloud_skills", "").split(","),
        "devops_tools": resume_metadata.get("devops_tools", "").split(",")
    }
    
    prompt = f"""You are an expert recruiter. Analyze how well this candidate matches the job requirements.

Job Requirements:
{json.dumps(jd_summary, indent=2)}

Candidate Profile:
{json.dumps(resume_summary, indent=2)}

Provide a detailed scoring analysis. Return ONLY a JSON object (no markdown):

{{
    "overall_score": 85,
    "skill_match_score": 90,
    "experience_match_score": 80,
    "tool_match_score": 85,
    "matched_skills": ["Python", "AWS", "Docker"],
    "missing_critical_skills": ["Kubernetes"],
    "missing_nice_to_have": ["React"],
    "strengths": ["Strong cloud experience", "Relevant tools"],
    "concerns": ["Less experience than required"],
    "recommendation": "Strong Match|Good Match|Moderate Match|Weak Match",
    "justification": "Brief explanation of the score"
}}

Score from 0-100. Be precise and analytical."""

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": 1500,
        "messages": [
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.3
    }
    
    try:
        response = bedrock.invoke_model(
            modelId=BEDROCK_LLM_MODEL,
            body=json.dumps(body)
        )
        
        result = json.loads(response['body'].read())
        content = result['content'][0]['text']
        
        # Clean JSON
        content = content.strip()
        if '```json' in content:
            content = content.split('```json')[1].split('```')[0]
        elif '```' in content:
            content = content.split('```')[1].split('```')[0]
        
        content = content.strip()
        score_data = json.loads(content)
        
        print(f"[CLAUDE] ✅ Match score calculated: {score_data.get('overall_score', 0)}/100")
        return score_data
        
    except Exception as e:
        print(f"[CLAUDE] ⚠️ Error calculating score: {e}")
        # Fallback to simple calculation
        return calculate_simple_match_score(jd_data, resume_metadata)


def calculate_simple_match_score(jd_data: Dict, resume_metadata: Dict) -> Dict:
    """
    Fallback simple skill matching when Claude is unavailable.
    
    Args:
        jd_data: Job description data
        resume_metadata: Resume metadata
    
    Returns:
        Basic scoring breakdown
    """
    print("[SCORING] Using simple skill matching...")
    
    # Extract skills from JD
    jd_skills = set()
    for key in ["technical_skills", "cloud_platforms", "tools", "must_have_skills"]:
        skills = jd_data.get(key, [])
        jd_skills.update([s.lower().strip() for s in skills if s.strip()])
    
    # Extract skills from resume
    resume_skills = set()
    for key in ["tech_skills", "cloud_skills", "devops_tools"]:
        skills_str = resume_metadata.get(key, "")
        skills = [s.lower().strip() for s in skills_str.split(",") if s.strip()]
        resume_skills.update(skills)
    
    # Calculate matches
    matched = jd_skills.intersection(resume_skills)
    missing = jd_skills - resume_skills
    
    # Calculate score
    skill_match_score = int((len(matched) / len(jd_skills)) * 100) if jd_skills else 0
    
    return {
        "overall_score": skill_match_score,
        "skill_match_score": skill_match_score,
        "experience_match_score": 0,
        "tool_match_score": 0,
        "matched_skills": list(matched),
        "missing_critical_skills": list(missing),
        "missing_nice_to_have": [],
        "strengths": [f"Matched {len(matched)} skills"],
        "concerns": [f"Missing {len(missing)} skills"],
        "recommendation": "Moderate Match" if skill_match_score >= 50 else "Weak Match",
        "justification": f"Simple skill matching: {skill_match_score}% match"
    }


# -------- API Endpoints --------

@app.post("/match-resume")
async def match_resume(request: ResumeMatchRequest):
    """
    Match a specific resume against a job description.
    
    Endpoint for matching resume with JD:
    - Extracts skills from JD using Claude
    - Retrieves resume data from S3 Vector
    - Calculates comprehensive match score using Bedrock
    
    Returns detailed matching analysis.
    """
    print(f"\n{'='*60}")
    print(f"[API] Processing resume match request")
    print(f"      Resume: {request.resume_name}")
    print(f"      JD Length: {len(request.job_description)} chars")
    print(f"{'='*60}\n")
    
    try:
        # Step 1: Extract skills from Job Description
        print("[STEP 1] Extracting skills from Job Description...")
        jd_data = extract_skills_with_claude(request.job_description, "job description")
        
        if "error" in jd_data:
            raise HTTPException(
                status_code=500,
                detail=f"Failed to extract JD skills: {jd_data['error']}"
            )
        
        # Step 2: Find the specific resume in S3 Vector
        print("[STEP 2] Searching for resume in S3 Vector...")
        resume_data = search_resume_by_name(request.resume_name)
        
        if not resume_data:
            raise HTTPException(
                status_code=404,
                detail=f"Resume not found: {request.resume_name}"
            )
        
        resume_metadata = resume_data['metadata']
        
        # Step 3: Calculate match score using Bedrock
        print("[STEP 3] Calculating match score with Bedrock...")
        match_score = calculate_match_score_with_bedrock(jd_data, resume_metadata)
        
        # Prepare response
        result = {
            "status": "success",
            "resume_info": {
                "name": resume_metadata.get("name", "Unknown"),
                "title": resume_metadata.get("title", ""),
                "years_experience": resume_metadata.get("years_exp", ""),
                "email": resume_metadata.get("email", ""),
                "file_name": resume_metadata.get("file_name", ""),
                "s3_uri": resume_metadata.get("s3_uri", "")
            },
            "job_requirements": {
                "title": jd_data.get("job_title", ""),
                "experience_required": jd_data.get("experience_required", ""),
                "must_have_skills": jd_data.get("must_have_skills", []),
                "nice_to_have_skills": jd_data.get("nice_to_have_skills", [])
            },
            "match_analysis": match_score
        }
        
        print(f"\n[SUCCESS] Match score: {match_score.get('overall_score', 0)}/100")
        print(f"          Recommendation: {match_score.get('recommendation', 'N/A')}")
        
        return result
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"[ERROR] {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/search-resumes")
async def search_resumes(request: ResumeMatchRequest):
    """
    Search for top matching resumes for a job description.
    
    Performs semantic search across all resumes and ranks them.
    """
    print(f"\n{'='*60}")
    print(f"[API] Searching resumes for JD")
    print(f"      JD Length: {len(request.job_description)} chars")
    print(f"      Top K: {request.top_k}")
    print(f"{'='*60}\n")
    
    try:
        # Step 1: Extract skills from Job Description
        print("[STEP 1] Extracting skills from Job Description...")
        jd_data = extract_skills_with_claude(request.job_description, "job description")
        
        # Step 2: Generate embedding for JD
        print("[STEP 2] Generating JD embedding...")
        jd_embedding = get_embedding(request.job_description)
        
        # Step 3: Semantic search in S3 Vector
        print("[STEP 3] Performing semantic search...")
        search_results = semantic_search_resumes(jd_embedding, top_k=request.top_k)
        
        # Step 4: Calculate match scores for each result
        print("[STEP 4] Calculating match scores...")
        ranked_results = []
        
        for result in search_results:
            metadata = result.get('metadata', {})
            
            # Calculate match score
            match_score = calculate_match_score_with_bedrock(jd_data, metadata)
            
            ranked_results.append({
                "candidate_name": metadata.get("name", "Unknown"),
                "title": metadata.get("title", ""),
                "years_experience": metadata.get("years_exp", ""),
                "email": metadata.get("email", ""),
                "file_name": metadata.get("file_name", ""),
                "overall_score": match_score.get("overall_score", 0),
                "recommendation": match_score.get("recommendation", ""),
                "matched_skills": match_score.get("matched_skills", []),
                "missing_skills": match_score.get("missing_critical_skills", []),
                "strengths": match_score.get("strengths", []),
                "concerns": match_score.get("concerns", [])
            })
        
        # Sort by score
        ranked_results.sort(key=lambda x: x["overall_score"], reverse=True)
        
        result = {
            "status": "success",
            "job_requirements": {
                "title": jd_data.get("job_title", ""),
                "must_have_skills": jd_data.get("must_have_skills", []),
                "nice_to_have_skills": jd_data.get("nice_to_have_skills", [])
            },
            "total_results": len(ranked_results),
            "candidates": ranked_results
        }
        
        print(f"\n[SUCCESS] Found {len(ranked_results)} matching candidates")
        if ranked_results:
            print(f"          Top candidate: {ranked_results[0]['candidate_name']} ({ranked_results[0]['overall_score']}/100)")
        
        return result
        
    except Exception as e:
        print(f"[ERROR] {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# -------- Lambda Handler --------
asgi_handler = Mangum(app)


def lambda_handler(event, context):
    """
    Hybrid handler supporting both:
    - API Gateway (via Mangum/FastAPI)
    - Bedrock Agent Function calls (messageVersion 1.0)
    """
    print("\n" + "="*60)
    print("[LAMBDA] Handler invoked")
    print("="*60)
    print(f"[EVENT] {json.dumps(event)}")
    
    try:
        # Check if this is a Bedrock Agent function call
        if "messageVersion" in event and "function" in event:
            print("[LAMBDA] Detected Bedrock Agent invocation")
            
            function_name = event.get("function")
            params = event.get("parameters", [])
            
            # Extract parameters
            resume_name = next((p["value"] for p in params if p["name"] == "resume_name"), None)
            job_description = next((p["value"] for p in params if p["name"] == "job_description"), None)
            
            if not resume_name or not job_description:
                raise ValueError("Missing required parameters: resume_name and job_description")
            
            # Create request object
            request = ResumeMatchRequest(
                resume_name=resume_name,
                job_description=job_description
            )
            
            # Route to appropriate function
            if function_name == "match_resume":
                # This is a blocking call, need to make it work in Lambda context
                import asyncio
                loop = asyncio.get_event_loop()
                result = loop.run_until_complete(match_resume(request))
            else:
                import asyncio
                loop = asyncio.get_event_loop()
                result = loop.run_until_complete(search_resumes(request))
            
            print(f"[LAMBDA] Function result: {result}")
            
            return {
                "messageVersion": "1.0",
                "response": {
                    "actionGroup": event.get("actionGroup"),
                    "function": function_name,
                    "functionResponse": {
                        "responseBody": {
                            "TEXT": {
                                "body": json.dumps(result)
                            }
                        }
                    }
                }
            }
        
        # Otherwise, delegate to FastAPI via Mangum
        print("[LAMBDA] Delegating to FastAPI via Mangum...")
        return asgi_handler(event, context)
        
    except Exception as e:
        print(f"[LAMBDA][ERROR] {str(e)}")
        import traceback
        traceback.print_exc()
        
        return {
            "messageVersion": "1.0",
            "response": {
                "actionGroup": event.get("actionGroup", ""),
                "function": event.get("function", ""),
                "functionResponse": {
                    "responseBody": {
                        "TEXT": {
                            "body": json.dumps({"error": str(e)})
                        }
                    }
                }
            }
        }
    finally:
        print("="*60)
        print("[LAMBDA] Handler completed")
        print("="*60 + "\n")


handler = lambda_handler
