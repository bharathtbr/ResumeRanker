import os, json, boto3, math, re, uuid
import psycopg2
import psycopg2.extras

AWS_REGION = os.getenv("AWS_REGION", "us-east-2")
VECTOR_BUCKET = os.getenv("VECTOR_BUCKET")
VECTOR_INDEX  = os.getenv("VECTOR_INDEX")

DB_NAME = os.getenv("PG_DB", "resumes")
DB_USER = os.getenv("PG_USER", "bharat")
DB_PASS = os.getenv("PG_PASS", "bharat@123")
DB_HOST = os.getenv("PG_HOST", "165.227.21.40")
DB_PORT = os.getenv("PG_PORT", "5432")

BEDROCK_EMBED_MODEL = os.getenv("BEDROCK_EMBED_MODEL", "amazon.titan-embed-text-v2:0")
BEDROCK_LLM_MODEL   = os.getenv("BEDROCK_LLM_MODEL", "us.anthropic.claude-3-5-sonnet-20241022-v2:0")

bedrock = boto3.client("bedrock-runtime", region_name=AWS_REGION)
s3vector = boto3.client("s3vectors", region_name=AWS_REGION)

def pg_conn():
    return psycopg2.connect(dbname=DB_NAME, user=DB_USER, password=DB_PASS, host=DB_HOST, port=DB_PORT)

# ---------- Bedrock ----------
def invoke_claude(prompt: str, max_tokens: int = 2500) -> str:
    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens": max_tokens,
        "messages": [{"role": "user", "content": prompt}],
        "temperature": 0.0
    }
    resp = bedrock.invoke_model(modelId=BEDROCK_LLM_MODEL, body=json.dumps(body))
    result = json.loads(resp["body"].read())
    text = result["content"][0]["text"].strip()
    if "```" in text:
        parts = text.split("```")
        text = max(parts, key=len).strip()
        if text.lower().startswith("json"):
            text = text[4:].strip()
    return text

def get_embedding(text: str):
    body = {"inputText": text[:8000]}
    resp = bedrock.invoke_model(
        modelId=BEDROCK_EMBED_MODEL,
        body=json.dumps(body),
        accept="application/json",
        contentType="application/json"
    )
    return json.loads(resp["body"].read())["embedding"]

def cosine_similarity(a, b) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x*y for x, y in zip(a, b))
    ma = math.sqrt(sum(x*x for x in a))
    mb = math.sqrt(sum(y*y for y in b))
    if ma == 0 or mb == 0:
        return 0.0
    return max(0.0, min(1.0, dot/(ma*mb)))

# ---------- Better JD extraction (variants forced) ----------
def extract_jd_requirements(jd_text: str) -> dict:
    jd_text = jd_text[:20000]
    prompt = f"""
Extract requirements from this Job Description.
Return ONLY JSON.

JD:
{jd_text}

Return:
{{
  "job_title": "",
  "core_skills": [
    {{"name":"","importance":"critical|required|preferred","min_years":0,"variants":[]}}
  ],
  "secondary_skills": [
    {{"name":"","importance":"required","min_years":0,"variants":[]}}
  ],
  "nice_to_have_skills": [
    {{"name":"","importance":"preferred","variants":[]}}
  ],
  "keywords": [],
  "experience_requirements": {{"total_years":0}}
}}

Rules:
- For ".NET / dotnet": include variants like ["dotnet",".net","ASP.NET Core",".NET 6",".NET 7",".NET 8","C#"].
- For "PostgreSQL": include variants like ["postgres","postgresql","RDS Postgres","Aurora PostgreSQL"].
- For AWS services: expand EC2/Lambda/EKS to include "Amazon EC2", "AWS Lambda", "Amazon EKS".
- Normalize Kubernetes variants: ["kubernetes","k8s","EKS","AKS"] when relevant.
- Include CI/CD variants: ["CI/CD","pipelines","GitHub Actions","Jenkins","Azure DevOps"] when relevant.
"""
    return json.loads(invoke_claude(prompt, max_tokens=2500))

# ---------- Resume fetch from Postgres ----------
def get_resume_profile(resume_id: str) -> dict:
    with pg_conn() as conn, conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("SELECT * FROM resume_profiles WHERE resume_id=%s", (resume_id,))
        row = cur.fetchone()
        return dict(row) if row else None

# ---------- Best chunk evidence from S3 Vectors ----------
def best_chunk_for_skill(resume_id: str, skill_name: str) -> dict:
    q = f"Resume evidence showing professional experience using {skill_name}, including projects and responsibilities"
    q_emb = get_embedding(q)

    resp = s3vector.query_vectors(
        vectorBucketName=VECTOR_BUCKET,
        indexName=VECTOR_INDEX,
        queryVector={"float32": q_emb},
        topK=50,
        returnMetadata=True
    )
    results = resp.get("matches", resp.get("results", resp.get("vectors", [])))

    best, best_score = None, 0.0
    for r in results:
        md = r.get("metadata", {}) or {}
        if md.get("type") != "content":
            continue
        if md.get("resume_id") != resume_id:
            continue

        score = r.get("score")
        if score is None:
            vec = r.get("vector", r.get("data", {}))
            if isinstance(vec, dict):
                vec = vec.get("float32", [])
            score = cosine_similarity(q_emb, vec) if vec else 0.0

        if float(score) > best_score:
            best_score = float(score)
            best = {
                "similarity": best_score,
                "chunk_text": md.get("chunk_text",""),
                "page": md.get("page",""),
                "chunk_index": md.get("chunk_index","")
            }

    return best or {"similarity": 0.0, "chunk_text": "", "page": "", "chunk_index": ""}

# ---------- Claude evidence grading ----------
def grade_skill_evidence(skill_obj: dict, chunk_text: str) -> dict:
    name = skill_obj["name"]
    min_years = int(skill_obj.get("min_years") or 0)

    prompt = f"""
You are grading resume evidence for a job requirement.

Skill: {name}
Minimum years required: {min_years}

Resume excerpt:
{chunk_text}

Return ONLY JSON:
{{
  "has_skill": true/false,
  "evidence_strength": "strong|moderate|weak|none",
  "years_supported": 0,
  "meets_years": true/false,
  "why": "one sentence",
  "quote": "exact short quote from excerpt (<=25 words)",
  "confidence": 0.0
}}

Rules:
- strong: clear used in work/projects/responsibilities
- weak: only mentions/familiar/exposure
- none: not supported by excerpt
- If years not explicit, years_supported=0 and meets_years=false when min_years>0
"""
    return json.loads(invoke_claude(prompt, max_tokens=900))

# ---------- Score ----------
def score_resume(resume: dict, jd_req: dict) -> dict:
    resume_id = resume["resume_id"]
    skills_flat = resume.get("skills_flat") or []
    skills_text = ", ".join([str(x) for x in skills_flat])[:6000]

    # Global semantic: JD skills vs resume skills list
    jd_names = [s["name"] for s in jd_req.get("core_skills", [])] + [s["name"] for s in jd_req.get("secondary_skills", [])]
    jd_text = ", ".join(jd_names)[:6000]

    sem_a = get_embedding(f"Job required skills: {jd_text}")
    sem_b = get_embedding(f"Candidate skills: {skills_text}")
    skills_sem = cosine_similarity(sem_a, sem_b)

    core = jd_req.get("core_skills", [])
    core_points = 0.0
    core_results = []

    for skill_obj in core:
        best = best_chunk_for_skill(resume_id, skill_obj["name"])
        if best["similarity"] < 0.55 or not best["chunk_text"]:
            evidence = {"has_skill": False, "evidence_strength": "none", "years_supported": 0, "meets_years": False, "why": "No supporting evidence found", "quote": "", "confidence": 0.0}
        else:
            evidence = grade_skill_evidence(skill_obj, best["chunk_text"])

        strength = evidence.get("evidence_strength","none")
        meets_years = bool(evidence.get("meets_years", False))

        if strength == "strong":
            pts = 1.0
        elif strength == "moderate":
            pts = 0.7
        elif strength == "weak":
            pts = 0.3
        else:
            pts = 0.0

        if int(skill_obj.get("min_years") or 0) > 0 and not meets_years:
            pts = min(pts, 0.4)

        core_points += pts
        core_results.append({
            "skill": skill_obj["name"],
            "min_years": skill_obj.get("min_years", 0),
            "chunk_similarity": round(best["similarity"], 4),
            "evidence": evidence,
            "page": best.get("page"),
            "chunk_index": best.get("chunk_index")
        })

    core_score = core_points / (len(core) if core else 1.0)

    # experience score
    req_years = int(jd_req.get("experience_requirements", {}).get("total_years") or 0)
    res_years = int(resume.get("years_exp") or 0)
    exp_score = 1.0 if res_years >= req_years else max(0.0, 1.0 - (req_years - res_years)*0.10)

    final = (
        0.60 * core_score +     # hardest-to-game dominates
        0.15 * skills_sem +     # semantic boost
        0.25 * exp_score        # years matter a lot for senior roles
    )

    return {
        "overall_score": int(round(final * 100)),
        "breakdown": {
            "core_evidence_score": round(core_score, 4),
            "skills_semantic_score": round(skills_sem, 4),
            "experience_score": round(exp_score, 4)
        },
        "core_skill_evidence": core_results,
        "resume_info": {
            "resume_id": resume_id,
            "name": resume.get("name",""),
            "title": resume.get("title",""),
            "years_exp": resume.get("years_exp",""),
            "email": resume.get("email",""),
            "phone": resume.get("phone",""),
            "file_name": resume.get("file_name","")
        }
    }

# ---------- Prompt parsing ----------
def parse_match_prompt(text: str) -> dict:
    m = re.search(r"Match\s+(.*?)\s+against\s+this\s+job\s+description:\s*(.*)$", text, flags=re.I|re.S)
    if not m:
        raise ValueError("Invalid prompt. Use: Match <resume_id> against this job description: <JD>")
    resume_id = m.group(1).strip().replace("/", "_")
    jd = m.group(2).strip()
    return {"resume_id": resume_id, "jd": jd}

def lambda_handler(event, context):
    try:
        prompt = event.get("prompt")
        if prompt:
            parsed = parse_match_prompt(prompt)
            resume_id = parsed["resume_id"]
            jd_text = parsed["jd"]
        else:
            resume_id = event["resume_id"].replace("/", "_")
            jd_text = event["job_description"]

        resume = get_resume_profile(resume_id)
        if not resume:
            return {"statusCode": 404, "body": json.dumps({"error": f"Resume not found: {resume_id}"})}

        jd_req = extract_jd_requirements(jd_text)
        result = score_resume(resume, jd_req)

        # (Optional) save match run
        run_id = str(uuid.uuid4())
        with pg_conn() as conn, conn.cursor() as cur:
            cur.execute("""
                INSERT INTO resume_match_runs(id, resume_id, jd_text, jd_requirements, result_json, overall_score)
                VALUES (%s,%s,%s,%s::jsonb,%s::jsonb,%s)
            """, (run_id, resume_id, jd_text, json.dumps(jd_req), json.dumps(result), result["overall_score"]))

        return {"statusCode": 200, "body": json.dumps({"jd_requirements": jd_req, "result": result}, indent=2)}

    except Exception as e:
        return {"statusCode": 500, "body": json.dumps({"error": str(e)})}
